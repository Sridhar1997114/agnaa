# 🎙️ BuzzVoice

> **Local System-Wide Voice Typing & Text-to-Speech Software for Windows**  
> Powered by OpenAI's Whisper (`faster-whisper`), inspired by [Buzz](https://github.com/chidiwilliams/buzz).

---

## ✨ Features

- **🎯 Works Across Any Desktop Application:**
  - Dictate or read text in Google Chrome, Microsoft Word, Excel, Notepad, WhatsApp, Discord, Slack, VS Code, terminals, AutoCAD, and any other Windows software.
- **⚡ Offline Speech-to-Text (Voice Typing):**
  - Powered by OpenAI's Whisper model (`faster-whisper`), running locally on your CPU or NVIDIA GPU with zero internet connection required.
  - Automatically types or pastes the transcribed speech directly into your active cursor position.
  - Automatically preserves and restores your previous clipboard contents so you never lose what you had copied.
- **🔊 System-Wide Text-to-Speech (TTS Reader):**
  - Highlight any text on your screen in any application, press the shortcut (`F9`), and BuzzVoice immediately reads it aloud.
  - Supports both **Offline Windows Voices** (Microsoft David, Microsoft Zira) and **Natural Neural Voices** (Microsoft Edge Neural).
- **🕹️ Global Keyboard Shortcuts:**
  - `F8`: Start / Stop Voice Typing (configurable to `Ctrl+Alt+Space` or any key).
  - `F9`: Read selected text aloud with Text-to-Speech (configurable to `Ctrl+Alt+S` or any key).
  - `Esc`: Instantly stop speech or cancel recording.
- **🎛️ Dual Recording Modes:**
  - **Toggle Mode:** Press the shortcut once to start speaking; press it again when you're done to transcribe and paste.
  - **Push-to-Talk Mode:** Hold the shortcut down while speaking; release it to instantly transcribe and paste.
- **🪟 Floating Capsule HUD (Non-Activating Overlay):**
  - A discreet, translucent floating pill on your screen that shows recording status, a live audio volume wave visualizer, transcribing progress, and preview text.
  - Uses Windows `WS_EX_NOACTIVATE` so it **never steals focus** from your active document or browser!
- **📋 Persistent History & Export:**
  - Keeps a history of your previous dictations and readings.
  - Search, copy, re-listen, or export your transcripts to `.txt` or `.csv`.
- **💻 System Tray Integration:**
  - Runs quietly in your system tray near the clock.
  - Right-click tray menu for quick actions, or double-click to open the dashboard.

---

## 🚀 Quick Start

### 1. Launching BuzzVoice

You can start BuzzVoice using any of the following methods:

- **Desktop Shortcut:** Double-click the **BuzzVoice** shortcut on your Desktop.
- **Silent Background Launch:** Double-click `Launch_BuzzVoice_Silent.vbs` (runs in the background with tray icon and floating overlay, zero console popup).
- **Console Launch:** Double-click `Launch_BuzzVoice.bat` (shows terminal logs).

---

## ⌨️ How to Use

### 🎙️ Voice Typing (Speech-to-Text) into Any App

1. Click into **any text box** in any application (e.g., Notepad, Chrome search bar, Word, WhatsApp, Discord).
2. Press **`F8`** (default shortcut).
3. The floating pill turns red: `🔴 Listening...` with a live sound wave meter.
4. Speak naturally into your microphone.
5. Press **`F8`** again (or release if using Push-to-Talk).
6. The floating pill shows `⏳ Transcribing...` and within milliseconds, your transcribed words are typed right where your cursor is!

### 🔊 Text-to-Speech (Read Aloud)

1. **Highlight / select any text** on your screen (in an article, email, PDF, or document).
2. Press **`F9`** (default shortcut).
3. BuzzVoice reads the text aloud in your chosen voice.
4. Press **`Esc`** at any time to immediately stop speaking.

---

## ⚙️ Customization & Settings

Open the BuzzVoice main window (click the tray icon or run the launcher) and go to the **⚙️ Settings** tab:

| Setting | Options | Description |
|---|---|---|
| **Voice Typing Hotkey** | `f8`, `ctrl+alt+space`, `alt+z`, etc. | Global shortcut to trigger speech-to-text. |
| **TTS Hotkey** | `f9`, `ctrl+alt+s`, etc. | Global shortcut to read highlighted text. |
| **Recording Style** | `Toggle` / `Push-to-Talk` | Press to start/stop OR hold while speaking. |
| **Whisper Model** | `tiny`, `base`, `small`, `medium` | `base` is recommended for high speed and accuracy. |
| **Hardware Acceleration** | `CPU (Int8)` / `CUDA (GPU)` | CPU is blazing fast; CUDA utilizes NVIDIA GPU. |
| **Speech Language** | `auto`, `en`, `es`, `fr`, `de`, `hi`, etc. | Language of your speech or auto-detection. |
| **Task** | `transcribe` / `translate` | Transcribe speech OR translate foreign speech into English! |
| **Microphone Device** | Dropdown list | Select your preferred microphone input. |
| **Floating HUD** | On / Off | Enable/disable the desktop status overlay. |
| **Sound Feedback** | On / Off | Play subtle audio beeps on start and stop. |

---

## 📁 Project Structure

```
d:\OPEN AI WHISPER\
├── src\
│   ├── config.py             # Settings manager & config.json persistence
│   ├── audio_recorder.py     # sounddevice 16kHz audio capture & RMS volume meter
│   ├── stt_engine.py         # faster-whisper local AI transcription engine
│   ├── tts_engine.py         # Windows SAPI5 & Edge Neural text-to-speech engine
│   ├── text_injector.py      # Win32 clipboard & keystroke paste injection
│   ├── hotkey_manager.py     # Global hotkeys for Toggle & Push-to-Talk
│   ├── sound_effects.py      # Audio feedback tones
│   ├── history_manager.py    # Local history logging & TXT/CSV export
│   ├── hud_overlay.py        # Non-activating floating capsule overlay
│   ├── gui.py                # Modern CustomTkinter desktop interface
│   ├── tray_icon.py          # System tray icon with context menu
│   └── app_controller.py     # Central coordinator
├── assets\
│   ├── icon.ico              # App icon
│   └── icon.png              # High-res icon
├── run_buzzvoice.py          # Python main entrypoint
├── Launch_BuzzVoice.bat      # 1-click batch launcher
├── Launch_BuzzVoice_Silent.vbs # 1-click silent background launcher
├── Create_Desktop_Shortcut.bat # Desktop shortcut generator
├── requirements.txt          # Python dependencies
└── README.md                 # Documentation
```

---

## 🛡️ Privacy & Offline Operation

- **100% Private:** Whisper runs completely locally on your hardware. No audio recordings or voice transcripts are ever sent to third-party servers.
- **Offline Capable:** Both Speech-to-Text and SAPI5 Text-to-Speech operate completely without an internet connection.
