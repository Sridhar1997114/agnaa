@echo off
title AGNAA Voice - Voice Typing ^& Speech AI
cd /d "%~dp0"

echo ========================================================
echo       Starting AGNAA Voice (AGNAA Design Studio)
echo                  https://agnaa.in
echo ========================================================
echo.

if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found! Please ensure .venv exists.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" run_buzzvoice.py

if %ERRORLEVEL% neq 0 (
    echo.
    echo AGNAA Voice exited with an error.
    pause
)
