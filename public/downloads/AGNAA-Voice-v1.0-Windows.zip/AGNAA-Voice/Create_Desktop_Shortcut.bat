@echo off
setlocal
cd /d "%~dp0"

echo Creating Desktop Shortcut for BuzzVoice...

powershell -NoProfile -ExecutionPolicy Bypass -Command "$desktop = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop); $ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut((Join-Path $desktop 'AGNAA Voice.lnk')); $s.TargetPath = '%~dp0Launch_AgnaaVoice.bat'; $s.WorkingDirectory = '%~dp0'; $s.IconLocation = '%~dp0assets\icon.ico'; $s.Description = 'AGNAA Voice - by AGNAA Design Studio (https://agnaa.in)'; $s.Save(); Write-Host '[SUCCESS] Shortcut created on Desktop: AGNAA Voice' -ForegroundColor Green"

pause
