#!/usr/bin/env python3
"""
BuzzVoice - System-Wide Voice Typing & Text-to-Speech Desktop Software
Powered by OpenAI's Whisper (faster-whisper)
"""

import sys
import os

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.app_controller import AppController
from src.gui import MainWindow

def main():
    try:
        controller = AppController()
        gui = MainWindow(controller)
        controller.init_ui_and_services(gui, gui)
        
        print("=" * 60)
        print("  AGNAA Voice is running! (AGNAA Design Studio - agnaa.in)")
        print(f"  * Global Dictation Shortcut: {controller.config.get('stt_hotkey', 'f8').upper()}")
        print(f"  * Global TTS Reader Shortcut: {controller.config.get('tts_hotkey', 'f9').upper()}")
        print(f"  * Stop/Cancel Shortcut:       {controller.config.get('stop_hotkey', 'esc').upper()}")
        print("=" * 60)
        
        gui.mainloop()
    except Exception as e:
        print(f"[BuzzVoice] Fatal error: {e}", flush=True)
        import traceback
        traceback.print_exc()
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "crash.log"), "w", encoding="utf-8") as f:
            traceback.print_exc(file=f)

if __name__ == "__main__":
    main()
