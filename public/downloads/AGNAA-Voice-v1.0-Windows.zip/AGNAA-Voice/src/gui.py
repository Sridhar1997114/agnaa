import os
import sys
import time
import threading
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import customtkinter as ctk

from .smart_formatter import SmartFormatter

# Set CustomTkinter theme
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# =============================================================================
# OFFICIAL AGNAA DESIGN STUDIO & FOUNDATION COLOR PALETTE (agnaa.in)
# =============================================================================
AGNAA_DARK   = "#0D0D14"  # Deep Obsidian base canvas
AGNAA_CARD   = "#14141F"  # Elevated brand card surface
AGNAA_BORDER = "#232338"  # Subtle hairline border
AGNAA_BORDER_GLOW = "#3A3362" # Highlighted border
AGNAA_NAVY   = "#1C1C72"  # Core Heritage Navy
AGNAA_PURPLE = "#4A259C"  # Mid Regal Purple
AGNAA_VIOLET = "#7B2DBF"  # Signature Electric Violet
AGNAA_LIGHT  = "#F0F0F6"  # Pure light foreground
AGNAA_MUTED  = "#8888AA"  # Secondary label text
AGNAA_ACCENT_TEXT = "#C084FC" # Soft illuminated lilac


class MainWindow(ctk.CTk):
    """
    World-class UI/UX Desktop Dashboard for AGNAA Voice.
    Strictly adheres to the AGNAA Design Studio & Foundation design system:
    - Official AGNAA brand colors (#0D0D14, #14141F, #1C1C72, #7B2DBF, #8888AA)
    - Tactile Glowing Voice Orb with state transitions
    - Real-Time Harmonic Soundwave Canvas in Agnaa Violet & Navy
    - Architectural / CAD Voice Mode
    - Floating Dynamic Capsule HUD
    """
    def __init__(self, app_controller):
        super().__init__()
        self.controller = app_controller
        self.config = app_controller.config
        
        self.title("AGNAA Voice - Voice Typing & Speech AI (agnaa.in)")
        self.geometry("880x690")
        self.minsize(820, 620)
        self.configure(fg_color=AGNAA_DARK)
        
        # Window icon
        icon_path = os.path.join(os.path.dirname(__file__), "..", "assets", "icon.ico")
        if os.path.exists(icon_path):
            try:
                self.iconbitmap(icon_path)
            except Exception:
                pass

        # Handle window close
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Build UI layout
        self._build_ui()
        
        # Audio level visualizer timer
        self._update_meter_loop()

    def _on_close(self):
        if self.config.get("auto_minimize_to_tray", True):
            self.withdraw()
        else:
            self.controller.shutdown()

    def _open_website(self):
        webbrowser.open("https://agnaa.in")

    def _build_ui(self):
        # Main Grid Layout
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ---------------------------------------------------------------------
        # 1. TOP NAVBAR / HEADER
        # ---------------------------------------------------------------------
        header = ctk.CTkFrame(
            self,
            height=74,
            corner_radius=0,
            fg_color=AGNAA_CARD,
            border_width=1,
            border_color=AGNAA_BORDER
        )
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        title_box = ctk.CTkFrame(header, fg_color="transparent")
        title_box.grid(row=0, column=0, padx=(22, 10), pady=12, sticky="w")

        # Load official AGNAA logo
        logo_path = os.path.join(os.path.dirname(__file__), "..", "assets", "icon.png")
        if os.path.exists(logo_path):
            try:
                pil_logo = Image.open(logo_path)
                self.logo_ctk = ctk.CTkImage(light_image=pil_logo, dark_image=pil_logo, size=(42, 42))
                logo_lbl = ctk.CTkLabel(title_box, image=self.logo_ctk, text="")
                logo_lbl.pack(side="left", padx=(0, 12))
            except Exception:
                pass

        text_sub_box = ctk.CTkFrame(title_box, fg_color="transparent")
        text_sub_box.pack(side="left")

        title_lbl = ctk.CTkLabel(
            text_sub_box,
            text="AGNAA Voice",
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color="#FFFFFF"
        )
        title_lbl.pack(anchor="w")

        sub_lbl = ctk.CTkLabel(
            text_sub_box,
            text="AGNAA Design Studio & Foundation • agnaa.in",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=AGNAA_ACCENT_TEXT
        )
        sub_lbl.pack(anchor="w")

        # Status badge
        self.status_badge = ctk.CTkLabel(
            header,
            text=f"Ready • Hotkey: {self.config.get('stt_hotkey', 'f8').upper()} • Model: {self.config.get('whisper_model', 'base').upper()}",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=AGNAA_MUTED
        )
        self.status_badge.grid(row=0, column=1, padx=14, pady=16, sticky="w")

        # Action Buttons in header
        btn_box_head = ctk.CTkFrame(header, fg_color="transparent")
        btn_box_head.grid(row=0, column=2, padx=22, pady=16, sticky="e")

        web_btn = ctk.CTkButton(
            btn_box_head,
            text="🌐 agnaa.in",
            width=96,
            height=32,
            fg_color=AGNAA_NAVY,
            hover_color=AGNAA_VIOLET,
            text_color=AGNAA_LIGHT,
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._open_website
        )
        web_btn.pack(side="left", padx=4)

        # ---------------------------------------------------------------------
        # 2. MAIN TABVIEW
        # ---------------------------------------------------------------------
        self.tabview = ctk.CTkTabview(
            self,
            corner_radius=14,
            fg_color=AGNAA_DARK,
            segmented_button_fg_color=AGNAA_CARD,
            segmented_button_selected_color=AGNAA_VIOLET,
            segmented_button_selected_hover_color=AGNAA_PURPLE,
            segmented_button_unselected_color=AGNAA_CARD,
            segmented_button_unselected_hover_color="#1D1D2C",
            text_color=AGNAA_LIGHT
        )
        self.tabview.grid(row=1, column=0, padx=20, pady=(10, 20), sticky="nsew")

        self.tab_dictate = self.tabview.add("🎙️ Voice Typing")
        self.tab_tts = self.tabview.add("🔊 Text-to-Speech")
        self.tab_history = self.tabview.add("📋 History & Transcripts")
        self.tab_settings = self.tabview.add("⚙️ Settings & Hardware")

        self._build_dictate_tab()
        self._build_tts_tab()
        self._build_history_tab()
        self._build_settings_tab()

    # =========================================================================
    # TAB 1: VOICE TYPING & HERO INTERFACE
    # =========================================================================
    def _build_dictate_tab(self):
        tab = self.tab_dictate
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(2, weight=1)

        # Mode Selector Bar (General / CAD Architect / Translate)
        mode_bar = ctk.CTkFrame(
            tab,
            fg_color=AGNAA_CARD,
            corner_radius=12,
            border_width=1,
            border_color=AGNAA_BORDER
        )
        mode_bar.grid(row=0, column=0, sticky="ew", pady=(0, 14), padx=2)
        mode_bar.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            mode_bar,
            text="📐 Typing Mode:",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=AGNAA_ACCENT_TEXT
        ).grid(row=0, column=0, padx=(16, 8), pady=10, sticky="w")

        self.mode_segment = ctk.CTkSegmentedButton(
            mode_bar,
            values=["⚡ Natural Dictation", "📐 CAD / Architect Mode", "🌐 Translate to English"],
            selected_color=AGNAA_VIOLET,
            selected_hover_color=AGNAA_PURPLE,
            unselected_color=AGNAA_DARK,
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._on_typing_mode_changed
        )
        self.mode_segment.set("⚡ Natural Dictation")
        self.mode_segment.grid(row=0, column=1, padx=8, pady=10, sticky="w")

        hk_reminder = ctk.CTkLabel(
            mode_bar,
            text=f"Global Shortcut: [{self.config.get('stt_hotkey', 'f8').upper()}]",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#38BDF8"
        )
        hk_reminder.grid(row=0, column=2, padx=16, pady=10, sticky="e")

        # HERO CARD: Big Tactile Voice Sphere + Live Waveform
        hero_card = ctk.CTkFrame(
            tab,
            fg_color=AGNAA_CARD,
            corner_radius=16,
            border_width=1,
            border_color=AGNAA_BORDER
        )
        hero_card.grid(row=1, column=0, sticky="ew", pady=(0, 14), padx=2)
        hero_card.grid_columnconfigure((0, 1, 2), weight=1)

        # Center Column: Orb + Audio Bars
        center_box = ctk.CTkFrame(hero_card, fg_color="transparent")
        center_box.grid(row=0, column=1, pady=18)

        # Big Voice Orb Button
        self.orb_btn = ctk.CTkButton(
            center_box,
            text="🎙️\nClick to Speak",
            font=ctk.CTkFont(size=18, weight="bold"),
            width=170,
            height=90,
            corner_radius=45,
            fg_color=AGNAA_NAVY,
            hover_color=AGNAA_PURPLE,
            border_width=2,
            border_color=AGNAA_VIOLET,
            command=self._on_mic_btn_clicked
        )
        self.orb_btn.pack(pady=(4, 12))

        # Real-time Smooth Waveform Canvas
        self.hero_wave_canvas = tk.Canvas(
            center_box,
            width=300,
            height=30,
            bg=AGNAA_CARD,
            highlightthickness=0
        )
        self.hero_wave_canvas.pack(pady=(0, 8))

        # Hero Status Line
        self.hero_status_lbl = ctk.CTkLabel(
            center_box,
            text="Press F8 anywhere in Windows or click above to dictate",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=AGNAA_MUTED
        )
        self.hero_status_lbl.pack()

        # TRANSCRIPT CARD: Latest Transcribed Output
        trans_card = ctk.CTkFrame(
            tab,
            fg_color=AGNAA_CARD,
            corner_radius=16,
            border_width=1,
            border_color=AGNAA_BORDER
        )
        trans_card.grid(row=2, column=0, sticky="nsew", padx=2)
        trans_card.grid_columnconfigure(0, weight=1)
        trans_card.grid_rowconfigure(1, weight=1)

        # Transcript Header Bar
        t_header = ctk.CTkFrame(trans_card, fg_color="transparent")
        t_header.grid(row=0, column=0, sticky="ew", padx=16, pady=(12, 6))
        t_header.grid_columnconfigure(0, weight=1)

        t_lbl = ctk.CTkLabel(
            t_header,
            text="Live Transcription Stream",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=AGNAA_LIGHT
        )
        t_lbl.grid(row=0, column=0, sticky="w")

        btn_box = ctk.CTkFrame(t_header, fg_color="transparent")
        btn_box.grid(row=0, column=1, sticky="e")

        copy_btn = ctk.CTkButton(
            btn_box,
            text="📋 Copy",
            width=75,
            height=30,
            fg_color="#1E1E2E",
            hover_color="#2D2D42",
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._copy_transcript
        )
        copy_btn.pack(side="left", padx=4)

        speak_btn = ctk.CTkButton(
            btn_box,
            text="🔊 Read Aloud",
            width=100,
            height=30,
            fg_color=AGNAA_NAVY,
            hover_color=AGNAA_VIOLET,
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._speak_transcript
        )
        speak_btn.pack(side="left", padx=4)

        clear_btn = ctk.CTkButton(
            btn_box,
            text="🗑️ Clear",
            width=75,
            height=30,
            fg_color="#2A2A38",
            hover_color="#3C3C4E",
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._clear_transcript
        )
        clear_btn.pack(side="left", padx=4)

        # Text Area
        self.transcript_box = ctk.CTkTextbox(
            trans_card,
            font=ctk.CTkFont(size=14, family="Segoe UI"),
            wrap="word",
            fg_color=AGNAA_DARK,
            border_width=1,
            border_color=AGNAA_BORDER,
            text_color=AGNAA_LIGHT,
            corner_radius=12
        )
        self.transcript_box.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 8))

        # Bottom Metrics Bar
        metrics_bar = ctk.CTkFrame(trans_card, fg_color="transparent")
        metrics_bar.grid(row=2, column=0, sticky="ew", padx=16, pady=(0, 12))
        metrics_bar.grid_columnconfigure(1, weight=1)

        self.words_lbl = ctk.CTkLabel(
            metrics_bar,
            text="Words: 0 | Characters: 0",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=AGNAA_MUTED
        )
        self.words_lbl.grid(row=0, column=0, sticky="w")

        self.time_lbl = ctk.CTkLabel(
            metrics_bar,
            text="Duration: 0.0s | Whisper base (100% offline)",
            font=ctk.CTkFont(size=11),
            text_color=AGNAA_MUTED
        )
        self.time_lbl.grid(row=0, column=1, sticky="e")

    def _on_typing_mode_changed(self, mode_name):
        if "CAD" in mode_name:
            self.config.set("typing_mode", "cad_architect")
            self.hero_status_lbl.configure(text="📐 CAD Mode: Automatically formats dimensions (e.g. 12' 6\", 300mm, COL C1)")
        elif "Translate" in mode_name:
            self.config.set("typing_mode", "translate")
            self.config.set("task", "translate")
            self.hero_status_lbl.configure(text="🌐 Translation Mode: Speak in Telugu, Hindi, etc., pastes in English!")
        else:
            self.config.set("typing_mode", "general")
            self.config.set("task", "transcribe")
            self.hero_status_lbl.configure(text="⚡ Natural Mode: Conversational speech with smart punctuation")

    def _on_mic_btn_clicked(self):
        self.controller.toggle_dictation()

    def update_dictation_ui_state(self, state, text=None, duration=0.0):
        if state == "recording":
            self.orb_btn.configure(
                text="🔴\nListening...",
                fg_color="#DC2626",
                hover_color="#B91C1C",
                border_color="#F87171"
            )
            self.hero_status_lbl.configure(text="Speaking... Click orb or press F8 again to finish", text_color="#F87171")
        elif state == "transcribing":
            self.orb_btn.configure(
                text="⏳\nTranscribing...",
                fg_color="#D97706",
                hover_color="#B45309",
                border_color="#FBBF24"
            )
            self.hero_status_lbl.configure(text="AI is processing speech offline...", text_color="#FCD34D")
        else:
            self.orb_btn.configure(
                text="🎙️\nClick to Speak",
                fg_color=AGNAA_NAVY,
                hover_color=AGNAA_PURPLE,
                border_color=AGNAA_VIOLET
            )
            self.hero_status_lbl.configure(text=f"Ready! Press [{self.config.get('stt_hotkey', 'f8').upper()}] anywhere to dictate", text_color=AGNAA_MUTED)
            self._render_idle_waveform()

        if text is not None:
            mode = self.config.get("typing_mode", "general")
            formatted = SmartFormatter.format_text(text, mode=mode)

            self.transcript_box.delete("1.0", "end")
            self.transcript_box.insert("1.0", formatted)

            words = len(formatted.split()) if formatted else 0
            chars = len(formatted)
            self.words_lbl.configure(text=f"Words: {words} | Characters: {chars}")
            if duration > 0:
                self.time_lbl.configure(text=f"Duration: {duration:.1f}s | Whisper {self.config.get('whisper_model', 'base')} (100% offline)")

    def _update_meter_loop(self):
        if self.controller.recorder.is_recording:
            rms = self.controller.recorder.current_level
            self._draw_waveform_bars(rms)
        self.after(50, self._update_meter_loop)

    def _draw_waveform_bars(self, rms: float):
        try:
            self.hero_wave_canvas.delete("all")
            num_bars = 26
            bar_w = 6
            gap = 5
            max_h = 26
            norm = min(1.0, rms * 20.0)

            for i in range(num_bars):
                import math
                wave_factor = 0.5 + 0.5 * math.sin(i * 0.45 + time.time() * 9)
                h = max(3, int(max_h * norm * wave_factor))
                x0 = i * (bar_w + gap) + 8
                y0 = (max_h - h) // 2 + 2
                x1 = x0 + bar_w
                y1 = y0 + h
                color = AGNAA_VIOLET if i % 2 == 0 else AGNAA_PURPLE
                self.hero_wave_canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline="")
        except Exception:
            pass

    def _render_idle_waveform(self):
        try:
            self.hero_wave_canvas.delete("all")
            num_bars = 26
            bar_w = 6
            gap = 5
            for i in range(num_bars):
                x0 = i * (bar_w + gap) + 8
                y0 = 13
                x1 = x0 + bar_w
                y1 = 16
                self.hero_wave_canvas.create_rectangle(x0, y0, x1, y1, fill="#232338", outline="")
        except Exception:
            pass

    def _copy_transcript(self):
        text = self.transcript_box.get("1.0", "end").strip()
        if text:
            import pyperclip
            pyperclip.copy(text)
            messagebox.showinfo("Copied", "Text copied to clipboard!")

    def _speak_transcript(self):
        text = self.transcript_box.get("1.0", "end").strip()
        if text:
            self.controller.tts.speak(text)

    def _clear_transcript(self):
        self.transcript_box.delete("1.0", "end")
        self.words_lbl.configure(text="Words: 0 | Characters: 0")

    # =========================================================================
    # TAB 2: TEXT-TO-SPEECH (TTS)
    # =========================================================================
    def _build_tts_tab(self):
        tab = self.tab_tts
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(2, weight=1)

        # Banner
        tts_hk = self.config.get("tts_hotkey", "f9").upper()
        banner = ctk.CTkFrame(tab, fg_color=AGNAA_CARD, corner_radius=12, border_width=1, border_color=AGNAA_BORDER)
        banner.grid(row=0, column=0, sticky="ew", pady=(0, 14), padx=2)

        banner_lbl = ctk.CTkLabel(
            banner,
            text=f"💡 Global Reader: Highlight any text on your screen and press [{tts_hk}] to hear it read aloud! (Esc to stop)",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=AGNAA_ACCENT_TEXT
        )
        banner_lbl.pack(pady=10, padx=14)

        # Controls Card
        controls_card = ctk.CTkFrame(tab, fg_color=AGNAA_CARD, corner_radius=16, border_width=1, border_color=AGNAA_BORDER)
        controls_card.grid(row=1, column=0, sticky="ew", pady=(0, 14), padx=2)
        controls_card.grid_columnconfigure((0, 1, 2), weight=1)

        # Voice Selector
        v_frame = ctk.CTkFrame(controls_card, fg_color="transparent")
        v_frame.grid(row=0, column=0, padx=16, pady=14, sticky="ew")
        ctk.CTkLabel(v_frame, text="Select Voice:", font=ctk.CTkFont(size=12, weight="bold"), text_color=AGNAA_LIGHT).pack(anchor="w")

        voices = self.controller.tts.get_all_voices()
        voice_names = [v["name"] for v in voices] or ["Default Windows Voice"]
        self.voice_combo = ctk.CTkComboBox(v_frame, values=voice_names, width=220, command=self._on_voice_changed)
        current_v = self.config.get("tts_voice", "")
        if current_v in voice_names:
            self.voice_combo.set(current_v)
        elif voice_names:
            self.voice_combo.set(voice_names[0])
        self.voice_combo.pack(pady=(4, 0), fill="x")

        # Speed Slider
        speed_frame = ctk.CTkFrame(controls_card, fg_color="transparent")
        speed_frame.grid(row=0, column=1, padx=16, pady=14, sticky="ew")
        self.speed_lbl = ctk.CTkLabel(speed_frame, text="Speech Speed: Normal", font=ctk.CTkFont(size=12, weight="bold"), text_color=AGNAA_LIGHT)
        self.speed_lbl.pack(anchor="w")
        self.speed_slider = ctk.CTkSlider(speed_frame, from_=-6, to=6, number_of_steps=12, progress_color=AGNAA_VIOLET, button_color=AGNAA_PURPLE, command=self._on_speed_changed)
        self.speed_slider.set(self.config.get("tts_rate", 0))
        self.speed_slider.pack(pady=(4, 0), fill="x")

        # Volume Slider
        vol_frame = ctk.CTkFrame(controls_card, fg_color="transparent")
        vol_frame.grid(row=0, column=2, padx=16, pady=14, sticky="ew")
        self.vol_lbl = ctk.CTkLabel(vol_frame, text=f"Volume: {self.config.get('tts_volume', 100)}%", font=ctk.CTkFont(size=12, weight="bold"), text_color=AGNAA_LIGHT)
        self.vol_lbl.pack(anchor="w")
        self.vol_slider = ctk.CTkSlider(vol_frame, from_=0, to=100, number_of_steps=20, progress_color=AGNAA_VIOLET, button_color=AGNAA_PURPLE, command=self._on_vol_changed)
        self.vol_slider.set(self.config.get("tts_volume", 100))
        self.vol_slider.pack(pady=(4, 0), fill="x")

        # Text Input Card
        text_card = ctk.CTkFrame(tab, fg_color=AGNAA_CARD, corner_radius=16, border_width=1, border_color=AGNAA_BORDER)
        text_card.grid(row=2, column=0, sticky="nsew", padx=2)
        text_card.grid_columnconfigure(0, weight=1)
        text_card.grid_rowconfigure(1, weight=1)

        t_bar = ctk.CTkFrame(text_card, fg_color="transparent")
        t_bar.grid(row=0, column=0, sticky="ew", padx=16, pady=(12, 6))
        t_bar.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(t_bar, text="Type or paste custom text to speak aloud:", font=ctk.CTkFont(size=14, weight="bold"), text_color=AGNAA_LIGHT).grid(row=0, column=0, sticky="w")

        btn_box2 = ctk.CTkFrame(t_bar, fg_color="transparent")
        btn_box2.grid(row=0, column=1, sticky="e")

        self.tts_play_btn = ctk.CTkButton(btn_box2, text="▶ Speak", width=80, height=30, fg_color="#059669", hover_color="#047857", font=ctk.CTkFont(size=12, weight="bold"), command=self._speak_input_text)
        self.tts_play_btn.pack(side="left", padx=4)

        self.tts_stop_btn = ctk.CTkButton(btn_box2, text="⏹ Stop", width=75, height=30, fg_color="#DC2626", hover_color="#B91C1C", font=ctk.CTkFont(size=12, weight="bold"), command=self._stop_tts)
        self.tts_stop_btn.pack(side="left", padx=4)

        self.tts_save_btn = ctk.CTkButton(btn_box2, text="💾 Save Audio", width=95, height=30, fg_color=AGNAA_VIOLET, hover_color=AGNAA_PURPLE, font=ctk.CTkFont(size=12, weight="bold"), command=self._save_tts_audio)
        self.tts_save_btn.pack(side="left", padx=4)

        self.tts_textbox = ctk.CTkTextbox(
            text_card,
            font=ctk.CTkFont(size=14, family="Segoe UI"),
            wrap="word",
            fg_color=AGNAA_DARK,
            border_width=1,
            border_color=AGNAA_BORDER,
            text_color=AGNAA_LIGHT,
            corner_radius=12
        )
        self.tts_textbox.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 16))
        self.tts_textbox.insert("1.0", "Welcome to AGNAA Voice! Developed by AGNAA Design Studio & Foundation (https://agnaa.in).\nHighlight any text anywhere in AutoCAD, Chrome, Word, or PDFs, and press F9 to hear it read aloud.")

    def _on_voice_changed(self, choice):
        self.config.set("tts_voice", choice)
        self.controller.tts.voice = choice

    def _on_speed_changed(self, value):
        val = int(value)
        self.config.set("tts_rate", val)
        self.controller.tts.rate = val
        desc = "Normal" if val == 0 else (f"+{val}" if val > 0 else f"{val}")
        self.speed_lbl.configure(text=f"Speech Speed: {desc}")

    def _on_vol_changed(self, value):
        val = int(value)
        self.config.set("tts_volume", val)
        self.controller.tts.volume = val
        self.vol_lbl.configure(text=f"Volume: {val}%")

    def _speak_input_text(self):
        text = self.tts_textbox.get("1.0", "end").strip()
        if text:
            self.controller.tts.speak(text)

    def _stop_tts(self):
        self.controller.tts.stop()

    def _save_tts_audio(self):
        text = self.tts_textbox.get("1.0", "end").strip()
        if not text:
            messagebox.showwarning("Empty Text", "Please enter some text to export.")
            return

        file_path = filedialog.asksaveasfilename(
            defaultextension=".wav",
            filetypes=[("WAV Audio", "*.wav"), ("MP3 Audio", "*.mp3")],
            title="Save Spoken Audio"
        )
        if file_path:
            ok = self.controller.tts.save_audio(text, file_path)
            if ok:
                messagebox.showinfo("Exported", f"Audio successfully saved to:\n{file_path}")
            else:
                messagebox.showerror("Export Failed", "Could not export audio file.")

    # =========================================================================
    # TAB 3: HISTORY & TRANSCRIPTS
    # =========================================================================
    def _build_history_tab(self):
        tab = self.tab_history
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(1, weight=1)

        # Toolbar
        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        toolbar.grid_columnconfigure(0, weight=1)

        self.hist_search = ctk.CTkEntry(
            toolbar,
            placeholder_text="🔍 Search history...",
            width=280,
            fg_color=AGNAA_CARD,
            border_color=AGNAA_BORDER,
            text_color=AGNAA_LIGHT
        )
        self.hist_search.grid(row=0, column=0, sticky="w", padx=2)
        self.hist_search.bind("<KeyRelease>", lambda e: self.refresh_history())

        btn_bar = ctk.CTkFrame(toolbar, fg_color="transparent")
        btn_bar.grid(row=0, column=1, sticky="e")

        ctk.CTkButton(btn_bar, text="💾 Export TXT", width=95, height=30, fg_color="#1E1E2E", hover_color="#2D2D42", font=ctk.CTkFont(size=12, weight="bold"), command=self._export_txt).pack(side="left", padx=4)
        ctk.CTkButton(btn_bar, text="📊 Export CSV", width=95, height=30, fg_color="#1E1E2E", hover_color="#2D2D42", font=ctk.CTkFont(size=12, weight="bold"), command=self._export_csv).pack(side="left", padx=4)
        ctk.CTkButton(btn_bar, text="🗑️ Clear All", width=85, height=30, fg_color="#DC2626", hover_color="#B91C1C", font=ctk.CTkFont(size=12, weight="bold"), command=self._clear_history).pack(side="left", padx=4)

        # Scrollable container for history items
        self.history_scroll = ctk.CTkScrollableFrame(
            tab,
            fg_color=AGNAA_CARD,
            corner_radius=16,
            border_width=1,
            border_color=AGNAA_BORDER
        )
        self.history_scroll.grid(row=1, column=0, sticky="nsew", padx=2)
        self.history_scroll.grid_columnconfigure(0, weight=1)

        self.refresh_history()

    def refresh_history(self):
        for widget in self.history_scroll.winfo_children():
            widget.destroy()

        query = self.hist_search.get().strip() if hasattr(self, "hist_search") else ""
        items = self.controller.history.get_entries(search_query=query)

        if not items:
            lbl = ctk.CTkLabel(self.history_scroll, text="No transcripts logged yet. Start speaking to see records here!", text_color=AGNAA_MUTED)
            lbl.pack(pady=40)
            return

        for item in items:
            card = ctk.CTkFrame(
                self.history_scroll,
                fg_color=AGNAA_DARK,
                corner_radius=12,
                border_width=1,
                border_color=AGNAA_BORDER
            )
            card.pack(fill="x", pady=5, padx=2)
            card.grid_columnconfigure(1, weight=1)

            type_icon = "🎙️" if item.get("type") == "stt" else "🔊"
            ctk.CTkLabel(card, text=type_icon, font=ctk.CTkFont(size=14)).grid(row=0, column=0, padx=(14, 6), pady=8, sticky="w")

            meta_text = f"{item.get('timestamp')} • {item.get('duration', 0)}s"
            if item.get("meta"):
                meta_text += f" • {item.get('meta')}"
            ctk.CTkLabel(card, text=meta_text, font=ctk.CTkFont(size=11, weight="bold"), text_color=AGNAA_ACCENT_TEXT).grid(row=0, column=1, sticky="w", pady=(8, 0))

            text_lbl = ctk.CTkLabel(card, text=item.get("text", ""), font=ctk.CTkFont(size=13), wraplength=550, justify="left", text_color=AGNAA_LIGHT)
            text_lbl.grid(row=1, column=1, sticky="w", pady=(2, 8))

            act_box = ctk.CTkFrame(card, fg_color="transparent")
            act_box.grid(row=0, column=2, rowspan=2, padx=14, sticky="e")

            txt = item.get("text", "")
            copy_b = ctk.CTkButton(act_box, text="Copy", width=55, height=26, fg_color="#1E1E2E", hover_color="#2D2D42", font=ctk.CTkFont(size=11, weight="bold"), command=lambda t=txt: self._copy_str(t))
            copy_b.pack(side="left", padx=2)

            play_b = ctk.CTkButton(act_box, text="Speak", width=55, height=26, fg_color=AGNAA_NAVY, hover_color=AGNAA_VIOLET, font=ctk.CTkFont(size=11, weight="bold"), command=lambda t=txt: self.controller.tts.speak(t))
            play_b.pack(side="left", padx=2)

    def _copy_str(self, text):
        import pyperclip
        pyperclip.copy(text)

    def _export_txt(self):
        f = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text File", "*.txt")])
        if f:
            if self.controller.history.export_txt(f):
                messagebox.showinfo("Exported", "History exported to TXT successfully!")

    def _export_csv(self):
        f = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV File", "*.csv")])
        if f:
            if self.controller.history.export_csv(f):
                messagebox.showinfo("Exported", "History exported to CSV successfully!")

    def _clear_history(self):
        if messagebox.askyesno("Clear History", "Are you sure you want to delete all history?"):
            self.controller.history.clear()
            self.refresh_history()

    # =========================================================================
    # TAB 4: SETTINGS, HARDWARE & ABOUT
    # =========================================================================
    def _build_settings_tab(self):
        tab = self.tab_settings
        tab.grid_columnconfigure((0, 1), weight=1)

        scroll = ctk.CTkScrollableFrame(
            tab,
            fg_color=AGNAA_CARD,
            corner_radius=16,
            border_width=1,
            border_color=AGNAA_BORDER
        )
        scroll.pack(fill="both", expand=True, padx=2, pady=2)
        scroll.grid_columnconfigure((0, 1), weight=1)

        # 1. Hotkeys Group
        grp1 = ctk.CTkFrame(scroll, fg_color=AGNAA_DARK, corner_radius=12, border_width=1, border_color=AGNAA_BORDER)
        grp1.grid(row=0, column=0, columnspan=2, sticky="ew", pady=6, padx=4)
        grp1.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(grp1, text="⌨️ Shortcuts & Input Mode", font=ctk.CTkFont(size=14, weight="bold"), text_color=AGNAA_ACCENT_TEXT).grid(row=0, column=0, columnspan=2, padx=16, pady=(14, 8), sticky="w")

        ctk.CTkLabel(grp1, text="Voice Typing Hotkey:", text_color=AGNAA_LIGHT).grid(row=1, column=0, padx=16, pady=6, sticky="w")
        self.stt_hk_entry = ctk.CTkEntry(grp1, width=180, fg_color=AGNAA_CARD, border_color=AGNAA_BORDER_GLOW, text_color=AGNAA_LIGHT)
        self.stt_hk_entry.insert(0, self.config.get("stt_hotkey", "f8"))
        self.stt_hk_entry.grid(row=1, column=1, padx=16, pady=6, sticky="w")

        ctk.CTkLabel(grp1, text="Text-to-Speech Hotkey:", text_color=AGNAA_LIGHT).grid(row=2, column=0, padx=16, pady=6, sticky="w")
        self.tts_hk_entry = ctk.CTkEntry(grp1, width=180, fg_color=AGNAA_CARD, border_color=AGNAA_BORDER_GLOW, text_color=AGNAA_LIGHT)
        self.tts_hk_entry.insert(0, self.config.get("tts_hotkey", "f9"))
        self.tts_hk_entry.grid(row=2, column=1, padx=16, pady=6, sticky="w")

        ctk.CTkLabel(grp1, text="Recording Style:", text_color=AGNAA_LIGHT).grid(row=3, column=0, padx=16, pady=6, sticky="w")
        self.mode_combo = ctk.CTkComboBox(grp1, values=["Toggle (Press to Start, Press to Stop)", "Push-to-Talk (Hold to Speak)"], width=300)
        curr_mode = self.config.get("recording_mode", "toggle")
        self.mode_combo.set("Push-to-Talk (Hold to Speak)" if curr_mode == "push_to_talk" else "Toggle (Press to Start, Press to Stop)")
        self.mode_combo.grid(row=3, column=1, padx=16, pady=6, sticky="w")

        # 2. AI Whisper Engine Group
        grp2 = ctk.CTkFrame(scroll, fg_color=AGNAA_DARK, corner_radius=12, border_width=1, border_color=AGNAA_BORDER)
        grp2.grid(row=1, column=0, columnspan=2, sticky="ew", pady=6, padx=4)
        grp2.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(grp2, text="🤖 Offline AI Whisper Engine (OpenAI)", font=ctk.CTkFont(size=14, weight="bold"), text_color=AGNAA_ACCENT_TEXT).grid(row=0, column=0, columnspan=2, padx=16, pady=(14, 8), sticky="w")

        ctk.CTkLabel(grp2, text="Model Size:", text_color=AGNAA_LIGHT).grid(row=1, column=0, padx=16, pady=6, sticky="w")
        self.model_combo = ctk.CTkComboBox(grp2, values=["tiny (Fastest, ~40MB)", "base (Recommended, ~140MB)", "small (High Accuracy, ~460MB)", "medium (~1.5GB)"], width=280)
        curr_m = self.config.get("whisper_model", "base")
        for val in self.model_combo._values:
            if val.startswith(curr_m):
                self.model_combo.set(val)
                break
        self.model_combo.grid(row=1, column=1, padx=16, pady=6, sticky="w")

        ctk.CTkLabel(grp2, text="Hardware Acceleration:", text_color=AGNAA_LIGHT).grid(row=2, column=0, padx=16, pady=6, sticky="w")
        self.dev_combo = ctk.CTkComboBox(grp2, values=["CPU (Optimized Int8)", "CUDA (NVIDIA GPU)"], width=200)
        self.dev_combo.set("CUDA (NVIDIA GPU)" if self.config.get("device") == "cuda" else "CPU (Optimized Int8)")
        self.dev_combo.grid(row=2, column=1, padx=16, pady=6, sticky="w")

        ctk.CTkLabel(grp2, text="Speech Language:", text_color=AGNAA_LIGHT).grid(row=3, column=0, padx=16, pady=6, sticky="w")
        self.lang_combo = ctk.CTkComboBox(grp2, values=["auto (Auto Detect)", "en (English)", "te (Telugu)", "hi (Hindi)", "ta (Tamil)", "es (Spanish)", "fr (French)", "de (German)"], width=200)
        curr_l = self.config.get("language", "auto")
        for val in self.lang_combo._values:
            if val.startswith(curr_l):
                self.lang_combo.set(val)
                break
        self.lang_combo.grid(row=3, column=1, padx=16, pady=6, sticky="w")

        # 3. Microphone & Audio Hardware Group
        grp3 = ctk.CTkFrame(scroll, fg_color=AGNAA_DARK, corner_radius=12, border_width=1, border_color=AGNAA_BORDER)
        grp3.grid(row=2, column=0, columnspan=2, sticky="ew", pady=6, padx=4)
        grp3.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(grp3, text="🎙️ Microphone Hardware & Desktop HUD", font=ctk.CTkFont(size=14, weight="bold"), text_color=AGNAA_ACCENT_TEXT).grid(row=0, column=0, columnspan=2, padx=16, pady=(14, 8), sticky="w")

        ctk.CTkLabel(grp3, text="Audio Input Device:", text_color=AGNAA_LIGHT).grid(row=1, column=0, padx=16, pady=6, sticky="w")
        devs = self.controller.recorder.list_input_devices()
        dev_names = ["Default System Microphone"] + [f"{d['index']}: {d['name']}" for d in devs]
        self.mic_combo = ctk.CTkComboBox(grp3, values=dev_names, width=320)
        saved_idx = self.config.get("input_device_index")
        if saved_idx is not None:
            for name in dev_names:
                if name.startswith(f"{saved_idx}:"):
                    self.mic_combo.set(name)
                    break
        else:
            self.mic_combo.set("Default System Microphone")
        self.mic_combo.grid(row=1, column=1, padx=16, pady=6, sticky="w")

        self.hud_switch = ctk.CTkSwitch(grp3, text="Show Floating Dynamic Capsule HUD on Desktop", progress_color=AGNAA_VIOLET)
        if self.config.get("show_hud", True):
            self.hud_switch.select()
        self.hud_switch.grid(row=2, column=0, columnspan=2, padx=16, pady=6, sticky="w")

        self.sound_switch = ctk.CTkSwitch(grp3, text="Play Subtle Acoustic Chimes on Start / Stop", progress_color=AGNAA_VIOLET)
        if self.config.get("sound_feedback", True):
            self.sound_switch.select()
        self.sound_switch.grid(row=3, column=0, columnspan=2, padx=16, pady=6, sticky="w")

        self.space_switch = ctk.CTkSwitch(grp3, text="Auto Trailing Space After Dictation", progress_color=AGNAA_VIOLET)
        if self.config.get("trailing_space", True):
            self.space_switch.select()
        self.space_switch.grid(row=4, column=0, columnspan=2, padx=16, pady=6, sticky="w")

        self.tray_switch = ctk.CTkSwitch(grp3, text="Minimize to Taskbar Tray When Window is Closed", progress_color=AGNAA_VIOLET)
        if self.config.get("auto_minimize_to_tray", True):
            self.tray_switch.select()
        self.tray_switch.grid(row=5, column=0, columnspan=2, padx=16, pady=6, sticky="w")

        # Save Button Frame
        save_card = ctk.CTkFrame(scroll, fg_color="transparent")
        save_card.grid(row=3, column=0, columnspan=2, pady=18, sticky="ew")

        save_btn = ctk.CTkButton(
            save_card,
            text="💾 Save & Apply All Settings",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=44,
            fg_color=AGNAA_VIOLET,
            hover_color=AGNAA_PURPLE,
            command=self._save_settings
        )
        save_btn.pack(side="left", padx=4)

        # 4. About AGNAA Studio & Foundation
        grp4 = ctk.CTkFrame(scroll, fg_color=AGNAA_DARK, corner_radius=12, border_width=1, border_color=AGNAA_BORDER_GLOW)
        grp4.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(10, 18), padx=4)
        grp4.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(grp4, text="🏢 About AGNAA Design Studio & Foundation", font=ctk.CTkFont(size=14, weight="bold"), text_color=AGNAA_ACCENT_TEXT).pack(anchor="w", padx=16, pady=(14, 4))
        ctk.CTkLabel(
            grp4,
            text="AGNAA Voice is an offline, privacy-first productivity tool built by AGNAA Design Studio (Hyderabad, India).\nEngineered for architects, engineers, CAD draftsmen, and digital creators to speak and dictate effortlessly.\nOfficial Website: https://agnaa.in",
            justify="left",
            font=ctk.CTkFont(size=12),
            text_color=AGNAA_MUTED
        ).pack(anchor="w", padx=16, pady=(0, 10))

        visit_btn = ctk.CTkButton(
            grp4,
            text="🌐 Visit agnaa.in",
            width=140,
            height=32,
            fg_color=AGNAA_NAVY,
            hover_color=AGNAA_VIOLET,
            font=ctk.CTkFont(size=12, weight="bold"),
            command=self._open_website
        )
        visit_btn.pack(anchor="w", padx=16, pady=(0, 14))

    def _save_settings(self):
        stt_hk = self.stt_hk_entry.get().strip().lower()
        tts_hk = self.tts_hk_entry.get().strip().lower()
        mode = "push_to_talk" if "Push-to-Talk" in self.mode_combo.get() else "toggle"

        model_str = self.model_combo.get().split()[0].lower()
        dev_str = "cuda" if "CUDA" in self.dev_combo.get() else "cpu"
        lang_str = self.lang_combo.get().split()[0].lower()

        mic_sel = self.mic_combo.get()
        dev_idx = None
        if ":" in mic_sel:
            try:
                dev_idx = int(mic_sel.split(":")[0])
            except Exception:
                dev_idx = None

        updates = {
            "stt_hotkey": stt_hk,
            "tts_hotkey": tts_hk,
            "recording_mode": mode,
            "whisper_model": model_str,
            "device": dev_str,
            "language": lang_str,
            "input_device_index": dev_idx,
            "show_hud": bool(self.hud_switch.get()),
            "sound_feedback": bool(self.sound_switch.get()),
            "trailing_space": bool(self.space_switch.get()),
            "auto_minimize_to_tray": bool(self.tray_switch.get())
        }

        self.config.update(updates)
        self.controller.apply_settings_update()

        self.status_badge.configure(
            text=f"Ready • Hotkey: {stt_hk.upper()} • Model: {model_str.upper()}"
        )
        messagebox.showinfo("Settings Saved", "Settings applied successfully!")
