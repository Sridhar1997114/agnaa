import time
import threading
import numpy as np
from faster_whisper import WhisperModel

class STTEngine:
    def __init__(self, model_size="base", device="cpu", compute_type="int8", on_status_change=None):
        self.model_size = model_size
        self.device = device
        self.compute_type = compute_type
        self.on_status_change = on_status_change
        
        self.model = None
        self._lock = threading.Lock()
        self.is_loading = False

    def load(self, model_size=None, device=None, compute_type=None):
        with self._lock:
            if model_size:
                self.model_size = model_size
            if device:
                self.device = device
            if compute_type:
                self.compute_type = compute_type
            self.is_loading = True
            
        if self.on_status_change:
            self.on_status_change(f"Loading Whisper ({self.model_size})...")
            
        try:
            print(f"[STTEngine] Loading Whisper model '{self.model_size}' on {self.device} ({self.compute_type})...")
            try:
                # Try loading from local cache first for instant offline startup (< 1 sec)
                model = WhisperModel(
                    self.model_size,
                    device=self.device,
                    compute_type=self.compute_type,
                    local_files_only=True
                )
            except Exception:
                # Fallback to online fetch if not yet in cache
                model = WhisperModel(
                    self.model_size,
                    device=self.device,
                    compute_type=self.compute_type,
                    local_files_only=False
                )
            
            # Warm up model with 0.1s silence
            warmup = np.zeros(1600, dtype=np.float32)
            try:
                list(model.transcribe(warmup, beam_size=1)[0])
            except Exception:
                pass
                
            with self._lock:
                self.model = model
                self.is_loading = False
                
            print(f"[STTEngine] Whisper model '{self.model_size}' loaded successfully!")
            if self.on_status_change:
                self.on_status_change("Ready")
            return True
        except Exception as e:
            print(f"[STTEngine] Failed to load model '{self.model_size}': {e}")
            with self._lock:
                self.is_loading = False
            if self.on_status_change:
                self.on_status_change(f"Error: {e}")
            return False

    def transcribe(self, audio_data: np.ndarray, language: str = "auto", task: str = "transcribe") -> tuple[str, str, float]:
        """
        Transcribes a 1D float32 numpy array sampled at 16000 Hz.
        Returns: (transcribed_text, detected_language, processing_time_sec)
        """
        if audio_data is None or len(audio_data) < 1600: # Less than 0.1s
            return "", "en", 0.0

        with self._lock:
            model = self.model
            
        if model is None:
            print("[STTEngine] Model is not loaded!")
            return "", "en", 0.0

        start_time = time.time()
        lang_arg = None if (not language or language == "auto") else language

        try:
            segments, info = model.transcribe(
                audio_data,
                beam_size=3,
                language=lang_arg,
                task=task,
                vad_filter=True, # Built-in silero VAD to strip silence
                vad_parameters=dict(min_silence_duration_ms=400)
            )

            text_parts = []
            for seg in segments:
                text_parts.append(seg.text)
                
            full_text = " ".join(text_parts).strip()
            detected_lang = info.language if info else (language or "en")
            proc_time = time.time() - start_time
            return full_text, detected_lang, proc_time
        except Exception as e:
            print(f"[STTEngine] Transcription error: {e}")
            return "", "en", 0.0
