import os
import json
from pathlib import Path

DEFAULT_CONFIG = {
    "stt_hotkey": "f8",
    "tts_hotkey": "f9",
    "stop_hotkey": "esc",
    "recording_mode": "toggle",         # "toggle" or "push_to_talk"
    "whisper_model": "base",            # "tiny", "base", "small", "medium"
    "device": "cpu",                    # "cpu" or "cuda"
    "compute_type": "int8",             # "int8", "float32", "float16"
    "language": "auto",                 # "auto", "en", "es", "fr", "de", "hi", etc.
    "task": "transcribe",               # "transcribe" or "translate"
    "input_device_index": None,         # None for system default
    "paste_method": "clipboard",        # "clipboard" or "type"
    "trailing_space": True,
    "sound_feedback": True,
    "tts_engine": "sapi5",              # "sapi5" or "edge_tts"
    "tts_voice": "",                    # Name or ID
    "tts_rate": 0,                      # SAPI5: -10 to +10, Edge: "+0%"
    "tts_volume": 100,                  # 0 to 100
    "show_hud": True,
    "hud_x": None,
    "hud_y": None,
    "auto_minimize_to_tray": True,
    "start_on_boot": False,
    "vad_silence_stop": False,          # Auto-stop on 2s silence
    "vad_silence_duration": 2.0
}

class ConfigManager:
    def __init__(self, config_path: str = None):
        if config_path is None:
            base_dir = Path(__file__).resolve().parent.parent
            self.config_path = base_dir / "config.json"
        else:
            self.config_path = Path(config_path)
            
        self.config = DEFAULT_CONFIG.copy()
        self.load()

    def load(self):
        if self.config_path.exists():
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    self.config.update(loaded)
            except Exception as e:
                print(f"[ConfigManager] Error loading config: {e}")
        else:
            self.save()

    def save(self):
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=4)
        except Exception as e:
            print(f"[ConfigManager] Error saving config: {e}")

    def get(self, key, default=None):
        return self.config.get(key, default)

    def set(self, key, value):
        self.config[key] = value
        self.save()

    def update(self, key_values: dict):
        self.config.update(key_values)
        self.save()
