import re

class SmartFormatter:
    """
    Intelligent post-processor for voice typing.
    Includes specialized formatting for Architectural / CAD drawings, dimensions,
    and general clean dictation.
    """

    @staticmethod
    def format_text(text: str, mode: str = "general") -> str:
        if not text:
            return ""

        text = text.strip()

        if mode == "cad_architect":
            text = SmartFormatter.format_architectural(text)
        elif mode == "clean_dictation":
            text = SmartFormatter.format_clean(text)

        return text

    @staticmethod
    def format_architectural(text: str) -> str:
        """
        Specialized formatting for architects, engineers, and CAD/BIM drafting:
        - "12 feet 6 inches" -> 12' 6"
        - "10 feet" -> 10'
        - "6 inches" -> 6"
        - "300 millimeters" / "300 mm" -> 300mm
        - "level plus 200" -> LVL +200
        - "column c 1" -> COL C1
        - "beam b 2" -> BEAM B2
        - "grid 4" -> GRID 4
        """
        # Convert "X feet Y inches" -> X' Y"
        text = re.sub(r'(\d+)\s*(?:feet|foot|ft)\s*(\d+)\s*(?:inches|inch|in)', "\\1' \\2\"", text, flags=re.IGNORECASE)
        # Convert "X feet" -> X'
        text = re.sub(r'(\d+)\s*(?:feet|foot|ft)\b', "\\1'", text, flags=re.IGNORECASE)
        # Convert "X inches" -> X"
        text = re.sub(r'(\d+)\s*(?:inches|inch|in)\b', "\\1\"", text, flags=re.IGNORECASE)

        # Millimeters / meters
        text = re.sub(r'(\d+)\s*(?:millimeters|millimeter|mm)\b', r'\1mm', text, flags=re.IGNORECASE)
        text = re.sub(r'(\d+(?:\.\d+)?)\s*(?:meters|meter|m)\b', r'\1m', text, flags=re.IGNORECASE)

        # Architectural terms
        text = re.sub(r'\b(?:level|lvl)\s*(?:plus|\+)\s*(\d+)', r'LVL +\1', text, flags=re.IGNORECASE)
        text = re.sub(r'\bcolumn\s*([a-z])\s*(\d+)', lambda m: f"COL {m.group(1).upper()}{m.group(2)}", text, flags=re.IGNORECASE)
        text = re.sub(r'\bbeam\s*([a-z])\s*(\d+)', lambda m: f"BEAM {m.group(1).upper()}{m.group(2)}", text, flags=re.IGNORECASE)
        text = re.sub(r'\bgrid\s*([a-z0-9]+)', lambda m: f"GRID {m.group(1).upper()}", text, flags=re.IGNORECASE)

        return text

    @staticmethod
    def format_clean(text: str) -> str:
        """Strips filler words (um, uh, like, you know)"""
        fillers = [r'\bum+\b', r'\buh+\b', r'\bah+\b', r'\byou know\b', r'\blike,\s*']
        for pattern in fillers:
            text = re.sub(pattern, '', text, flags=re.IGNORECASE)
        # Fix double spaces
        text = re.sub(r'\s{2,}', ' ', text).strip()
        return text
