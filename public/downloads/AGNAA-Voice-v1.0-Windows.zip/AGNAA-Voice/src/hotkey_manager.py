import time
import threading
import keyboard

class HotkeyManager:
    def __init__(self, config_manager, on_stt_toggle=None, on_stt_press=None, on_stt_release=None, on_tts_read=None, on_stop_action=None):
        self.config = config_manager
        self.on_stt_toggle = on_stt_toggle
        self.on_stt_press = on_stt_press
        self.on_stt_release = on_stt_release
        self.on_tts_read = on_tts_read
        self.on_stop_action = on_stop_action

        self._registered_hooks = []
        self._ptt_monitoring = False
        self._ptt_thread = None
        self._lock = threading.Lock()

    def register_all(self):
        self.unregister_all()
        
        stt_hk = self.config.get("stt_hotkey", "f8").lower().strip()
        tts_hk = self.config.get("tts_hotkey", "f9").lower().strip()
        stop_hk = self.config.get("stop_hotkey", "esc").lower().strip()
        mode = self.config.get("recording_mode", "toggle")

        # 1. Register STT Hotkey
        if stt_hk:
            try:
                if mode == "push_to_talk":
                    hk_id = keyboard.add_hotkey(stt_hk, self._handle_ptt_press, suppress=True)
                    self._registered_hooks.append(hk_id)
                else: # Toggle mode
                    hk_id = keyboard.add_hotkey(stt_hk, self._handle_toggle_press, suppress=True)
                    self._registered_hooks.append(hk_id)
                print(f"[HotkeyManager] Registered STT hotkey '{stt_hk}' (Mode: {mode})")
            except Exception as e:
                print(f"[HotkeyManager] Error registering STT hotkey '{stt_hk}': {e}")

        # 2. Register TTS Hotkey
        if tts_hk:
            try:
                hk_id = keyboard.add_hotkey(tts_hk, self._handle_tts_press, suppress=True)
                self._registered_hooks.append(hk_id)
                print(f"[HotkeyManager] Registered TTS hotkey '{tts_hk}'")
            except Exception as e:
                print(f"[HotkeyManager] Error registering TTS hotkey '{tts_hk}': {e}")

        # 3. Register Stop Hotkey (Esc)
        if stop_hk:
            try:
                hk_id = keyboard.add_hotkey(stop_hk, self._handle_stop_press, suppress=False)
                self._registered_hooks.append(hk_id)
            except Exception as e:
                print(f"[HotkeyManager] Error registering Stop hotkey '{stop_hk}': {e}")

    def unregister_all(self):
        with self._lock:
            self._ptt_monitoring = False
            for hook in self._registered_hooks:
                try:
                    keyboard.remove_hotkey(hook)
                except Exception:
                    pass
            self._registered_hooks = []

    def _handle_toggle_press(self):
        if self.on_stt_toggle:
            # Run callback in non-blocking thread so keyboard hook thread never blocks
            threading.Thread(target=self.on_stt_toggle, daemon=True).start()

    def _handle_ptt_press(self):
        with self._lock:
            if self._ptt_monitoring:
                return
            self._ptt_monitoring = True

        stt_hk = self.config.get("stt_hotkey", "f8").lower().strip()
        if self.on_stt_press:
            threading.Thread(target=self.on_stt_press, daemon=True).start()

        # Start thread waiting for key release
        def _monitor_release():
            # Extract main key (e.g. 'space' from 'ctrl+alt+space', or 'f8')
            keys = [k.strip() for k in stt_hk.split("+")]
            main_key = keys[-1]
            time.sleep(0.08)

            while self._ptt_monitoring:
                # Check if main key is released
                if not keyboard.is_pressed(main_key):
                    break
                time.sleep(0.03)

            with self._lock:
                self._ptt_monitoring = False

            if self.on_stt_release:
                self.on_stt_release()

        self._ptt_thread = threading.Thread(target=_monitor_release, daemon=True)
        self._ptt_thread.start()

    def _handle_tts_press(self):
        if self.on_tts_read:
            threading.Thread(target=self.on_tts_read, daemon=True).start()

    def _handle_stop_press(self):
        if self.on_stop_action:
            threading.Thread(target=self.on_stop_action, daemon=True).start()
