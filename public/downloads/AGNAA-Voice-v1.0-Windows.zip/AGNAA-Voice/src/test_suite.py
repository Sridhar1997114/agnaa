import sys
sys.path.insert(0, 'd:/OPEN AI WHISPER')
from src.app_controller import AppController
from src.gui import MainWindow
from src.smart_formatter import SmartFormatter

# Test smart formatter
cad_test = SmartFormatter.format_text("wall is 12 feet 6 inches and beam is 300 millimeters column c 1", mode="cad_architect")
print("CAD Formatting Test Result:", repr(cad_test))
assert "12' 6\"" in cad_test
assert "300mm" in cad_test
assert "COL C1" in cad_test
print("[PASS] CAD Smart Formatting working!")

ctrl = AppController()
gui = MainWindow(ctrl)
ctrl.init_ui_and_services(gui, gui)
gui.update()
print("[PASS] GUI loaded with AGNAA Voice and all features!")
gui.destroy()
print("[PASS] Clean destroy!")
