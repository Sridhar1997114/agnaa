import os
import re
import time
import asyncio
import threading
import tempfile
from pathlib import Path
import numpy as np

# Pygame for smooth, crystal-clear 24kHz audio playback
try:
    import pygame
    if not pygame.mixer.get_init():
        pygame.mixer.init(frequency=24000, size=-16, channels=2, buffer=1024)
except Exception:
    pass

# Kitten TTS from I:\Kitten TTS
KITTEN_AVAILABLE = False
try:
    from kittentts import KittenTTS
    import soundfile as sf
    KITTEN_AVAILABLE = True
except Exception as e:
    print(f"[TTSEngine] KittenTTS import warning: {e}")

# Offline SAPI5 via pywin32 COM
import win32com.client
import pythoncom

# Optional Edge TTS
try:
    import edge_tts
    EDGE_AVAILABLE = True
except Exception:
    EDGE_AVAILABLE = False


class TTSEngine:
    """
    Studio-Quality Neural Text-to-Speech Engine for AGNAA Voice.
    Features:
    - Primary Engine: Kitten TTS Mini 0.8 (Offline, Ultra-Smooth, Natural Human Voice at 24kHz)
    - Voices: Rosie (Agnaa Signature), Bella, Luna, Jasper, Bruno, Hugo, Kiki, Leo
    - Instant responsive playback via Pygame
    - Zero motherboard beeps
    - Graceful fallback to Edge Neural and SAPI5
    """
    def __init__(self, engine_type="kitten", voice="Rosie", rate=0, volume=100, on_speech_start=None, on_speech_end=None):
        self.engine_type = engine_type  # "kitten", "edge_tts", "sapi5"
        self.voice = voice or "Rosie"
        self.rate = rate                # -5 to +5 (speed adjustment)
        self.volume = volume            # 0 to 100
        self.on_speech_start = on_speech_start
        self.on_speech_end = on_speech_end
        
        self.is_speaking = False
        self._stop_requested = False
        self._lock = threading.Lock()
        self._current_thread = None

        # Kitten TTS model instance
        self._kitten_model = None
        self._kitten_loading = False

        # Preload KittenTTS asynchronously so speech is instantaneous
        if KITTEN_AVAILABLE:
            threading.Thread(target=self._preload_kitten, daemon=True).start()

    def _preload_kitten(self):
        with self._lock:
            if self._kitten_model is not None or self._kitten_loading:
                return
            self._kitten_loading = True
        try:
            print("[TTSEngine] Pre-loading Kitten TTS model (Mini 0.8)...")
            model = KittenTTS("KittenML/kitten-tts-mini-0.8")
            with self._lock:
                self._kitten_model = model
            print("[TTSEngine] Kitten TTS model loaded and ready!")
        except Exception as e:
            print(f"[TTSEngine] Failed to pre-load Kitten TTS: {e}")
        finally:
            with self._lock:
                self._kitten_loading = False

    def get_kitten_model(self):
        with self._lock:
            if self._kitten_model is not None:
                return self._kitten_model
        # If not yet loaded, load now
        try:
            print("[TTSEngine] Loading Kitten TTS model...")
            model = KittenTTS("KittenML/kitten-tts-mini-0.8")
            with self._lock:
                self._kitten_model = model
            return model
        except Exception as e:
            print(f"[TTSEngine] Error initializing Kitten TTS: {e}")
            return None

    def get_kitten_voices(self):
        if not KITTEN_AVAILABLE:
            return []
        return [
            {"name": "Kitten: Rosie (Warm & Natural • Agnaa)", "id": "Rosie", "type": "kitten"},
            {"name": "Kitten: Bella (Crisp & Professional)", "id": "Bella", "type": "kitten"},
            {"name": "Kitten: Luna (Soft & Serene)", "id": "Luna", "type": "kitten"},
            {"name": "Kitten: Jasper (Articulate Male)", "id": "Jasper", "type": "kitten"},
            {"name": "Kitten: Bruno (Deep Male)", "id": "Bruno", "type": "kitten"},
            {"name": "Kitten: Hugo (Dynamic Male)", "id": "Hugo", "type": "kitten"},
            {"name": "Kitten: Kiki (Lively)", "id": "Kiki", "type": "kitten"},
            {"name": "Kitten: Leo (Authoritative)", "id": "Leo", "type": "kitten"}
        ]

    def get_sapi5_voices(self):
        voices = []
        try:
            pythoncom.CoInitialize()
            sp = win32com.client.Dispatch("SAPI.SpVoice")
            v_list = sp.GetVoices()
            for i in range(v_list.Count):
                v = v_list.Item(i)
                desc = v.GetDescription()
                voices.append({"name": f"Windows: {desc}", "id": desc, "type": "sapi5"})
        except Exception as e:
            print(f"[TTSEngine] Error getting SAPI5 voices: {e}")
        return voices

    def get_popular_edge_voices(self):
        if not EDGE_AVAILABLE:
            return []
        return [
            {"name": "Edge: Jenny (US Neural)", "id": "en-US-JennyNeural", "type": "edge_tts"},
            {"name": "Edge: Guy (US Neural)", "id": "en-US-GuyNeural", "type": "edge_tts"},
            {"name": "Edge: Swara (India Neural)", "id": "hi-IN-SwaraNeural", "type": "edge_tts"},
            {"name": "Edge: Madhur (India Neural)", "id": "hi-IN-MadhurNeural", "type": "edge_tts"},
        ]

    def get_all_voices(self):
        v = self.get_kitten_voices()
        v.extend(self.get_popular_edge_voices())
        v.extend(self.get_sapi5_voices())
        return v

    def stop(self):
        self._stop_requested = True
        
        # Stop Pygame music
        try:
            if pygame.mixer.get_init():
                pygame.mixer.music.stop()
                pygame.mixer.music.unload()
        except Exception:
            pass

        # Stop SAPI5
        try:
            pythoncom.CoInitialize()
            sp = win32com.client.Dispatch("SAPI.SpVoice")
            sp.Speak("", 2) # SVSFPurgeBeforeSpeak
        except Exception:
            pass

        self.is_speaking = False
        if self.on_speech_end:
            try:
                self.on_speech_end()
            except Exception:
                pass

    def _clean_text(self, text: str) -> str:
        """Strip raw formatting, urls, and special chars for smooth natural reading"""
        # Replace URLs
        text = re.sub(r'https?://\S+', 'link', text)
        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def _speak_kitten(self, text: str, voice_name: str):
        temp_wav = None
        try:
            tts_model = self.get_kitten_model()
            if not tts_model:
                print("[TTSEngine] KittenTTS unavailable, falling back to SAPI5")
                self._speak_sapi5(text)
                return

            # Clean voice name
            v_target = voice_name
            if "Rosie" in v_target: v_target = "Rosie"
            elif "Bella" in v_target: v_target = "Bella"
            elif "Luna" in v_target: v_target = "Luna"
            elif "Jasper" in v_target: v_target = "Jasper"
            elif "Bruno" in v_target: v_target = "Bruno"
            elif "Hugo" in v_target: v_target = "Hugo"
            elif "Kiki" in v_target: v_target = "Kiki"
            elif "Leo" in v_target: v_target = "Leo"
            else: v_target = "Rosie"

            # Compute speed multiplier from rate (-5 to +5)
            # rate=0 -> speed=1.0, rate=-5 -> speed=0.75, rate=+5 -> speed=1.35
            speed = 1.0 + (self.rate * 0.07)
            speed = max(0.6, min(1.6, speed))

            cleaned = self._clean_text(text)
            if not cleaned or self._stop_requested:
                return

            print(f"[TTSEngine] Synthesizing with KittenTTS voice '{v_target}' (speed={speed:.2f})...")
            
            # Split long text by sentences to keep synthesis snappy and add natural breathing room
            sentences = re.split(r'(?<=[.!?])\s+', cleaned)
            sentences = [s.strip() for s in sentences if s.strip()]
            if not sentences:
                sentences = [cleaned]

            sample_rate = 24000
            pause = np.zeros(int(sample_rate * 0.25), dtype=np.float32)
            audio_parts = []

            for s in sentences:
                if self._stop_requested:
                    return
                # Synthesize chunk
                chunk = tts_model.generate(text=s, voice=v_target, speed=speed)
                audio_parts.append(chunk)
                audio_parts.append(pause)

            if not audio_parts or self._stop_requested:
                return

            combined = np.concatenate(audio_parts)

            # Write to temporary wav
            fd, temp_wav = tempfile.mkstemp(suffix=".wav")
            os.close(fd)
            sf.write(temp_wav, combined, sample_rate)

            if self._stop_requested:
                return

            # Play with Pygame
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=sample_rate, size=-16, channels=2, buffer=1024)

            pygame.mixer.music.load(temp_wav)
            pygame.mixer.music.set_volume(max(0.0, min(1.0, self.volume / 100.0)))
            pygame.mixer.music.play()

            # Wait while audio is playing
            while pygame.mixer.music.get_busy() and not self._stop_requested:
                time.sleep(0.03)

            if self._stop_requested:
                pygame.mixer.music.stop()

        except Exception as e:
            print(f"[TTSEngine] KittenTTS generation/playback error: {e}")
            if not self._stop_requested:
                self._speak_sapi5(text)
        finally:
            try:
                if pygame.mixer.get_init():
                    pygame.mixer.music.unload()
                if temp_wav and os.path.exists(temp_wav):
                    os.remove(temp_wav)
            except Exception:
                pass
            self.is_speaking = False
            if self.on_speech_end:
                try:
                    self.on_speech_end()
                except Exception:
                    pass

    def _speak_sapi5(self, text: str):
        try:
            pythoncom.CoInitialize()
            sp = win32com.client.Dispatch("SAPI.SpVoice")
            
            # Rate -10 to 10
            sp.Rate = int(max(-10, min(10, self.rate)))
            sp.Volume = int(max(0, min(100, self.volume)))
            
            # Match voice if set
            if self.voice and not ("Kitten" in self.voice or self.voice in ["Rosie", "Bella", "Luna", "Jasper", "Bruno"]):
                voices = sp.GetVoices()
                for i in range(voices.Count):
                    v = voices.Item(i)
                    if self.voice in v.GetDescription():
                        sp.Voice = v
                        break
                        
            # Start speaking asynchronously: SVSFlagsAsync = 1
            sp.Speak(text, 1)
            
            # Loop with WaitUntilDone polling so we keep sp alive and can cancel on stop
            while not sp.WaitUntilDone(100):
                if self._stop_requested:
                    sp.Speak("", 2)  # SVSFPurgeBeforeSpeak
                    break
                time.sleep(0.02)
                
        except Exception as e:
            print(f"[TTSEngine] SAPI5 speak error: {e}")
        finally:
            self.is_speaking = False
            if self.on_speech_end:
                try:
                    self.on_speech_end()
                except Exception:
                    pass

    def _speak_edge(self, text: str, voice_id: str):
        temp_file = None
        try:
            async def _generate():
                communicate = edge_tts.Communicate(text, voice_id)
                fd, path = tempfile.mkstemp(suffix=".mp3")
                os.close(fd)
                await communicate.save(path)
                return path

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            temp_file = loop.run_until_complete(_generate())
            loop.close()

            if self._stop_requested:
                return

            if not pygame.mixer.get_init():
                pygame.mixer.init()

            pygame.mixer.music.load(temp_file)
            pygame.mixer.music.set_volume(self.volume / 100.0)
            pygame.mixer.music.play()

            while pygame.mixer.music.get_busy() and not self._stop_requested:
                time.sleep(0.04)

            if self._stop_requested:
                pygame.mixer.music.stop()

        except Exception as e:
            print(f"[TTSEngine] Edge TTS error: {e}")
            self._speak_sapi5(text)
            return
        finally:
            if temp_file and os.path.exists(temp_file):
                try:
                    pygame.mixer.music.unload()
                    os.remove(temp_file)
                except Exception:
                    pass
            self.is_speaking = False
            if self.on_speech_end:
                try:
                    self.on_speech_end()
                except Exception:
                    pass

    def speak(self, text: str):
        if not text or not text.strip():
            return
            
        self.stop()
        self._stop_requested = False
        self.is_speaking = True
        
        if self.on_speech_start:
            try:
                self.on_speech_start()
            except Exception:
                pass

        def _worker():
            # Determine engine based on voice selection
            v = self.voice or ""
            is_edge = v.endswith("Neural") or "Edge" in v
            is_sapi = "Windows" in v or "Desktop" in v
            
            if not is_edge and not is_sapi and KITTEN_AVAILABLE:
                self._speak_kitten(text, v)
            elif is_edge and EDGE_AVAILABLE:
                # Extract voice ID
                v_id = v.split(":")[-1].strip() if ":" in v else v
                self._speak_edge(text, v_id)
            else:
                self._speak_sapi5(text)

        self._current_thread = threading.Thread(target=_worker, daemon=True)
        self._current_thread.start()

    def save_audio(self, text: str, output_path: str):
        """Export text to studio audio file (.wav or .mp3)"""
        if not text:
            return False
            
        v = self.voice or "Rosie"
        if KITTEN_AVAILABLE and not (v.endswith("Neural") or "Windows" in v):
            try:
                tts_model = self.get_kitten_model()
                v_target = "Rosie"
                for known in ['Rosie', 'Bella', 'Luna', 'Jasper', 'Bruno', 'Hugo', 'Kiki', 'Leo']:
                    if known in v:
                        v_target = known
                        break
                speed = max(0.6, min(1.6, 1.0 + (self.rate * 0.07)))
                cleaned = self._clean_text(text)
                audio = tts_model.generate(text=cleaned, voice=v_target, speed=speed)
                sf.write(output_path, audio, 24000)
                return True
            except Exception as e:
                print(f"[TTSEngine] Kitten save error: {e}")
                # Fallback to SAPI
        
        # Edge save fallback
        if EDGE_AVAILABLE and v.endswith("Neural"):
            try:
                async def _save():
                    comm = edge_tts.Communicate(text, v)
                    await comm.save(output_path)
                asyncio.run(_save())
                return True
            except Exception as e:
                print(f"[TTSEngine] Edge save error: {e}")

        # SAPI5 save fallback
        try:
            pythoncom.CoInitialize()
            sp = win32com.client.Dispatch("SAPI.SpVoice")
            fs = win32com.client.Dispatch("SAPI.SpFileStream")
            fs.Open(output_path, 3) # SSFMCreateForWrite
            sp.AudioOutputStream = fs
            sp.Speak(text)
            fs.Close()
            return True
        except Exception as e:
            print(f"[TTSEngine] SAPI save error: {e}")
            return False
