import os
import time
import asyncio
import threading
import tempfile
from pathlib import Path

# Offline SAPI5 via pywin32 COM
import win32com.client
import pythoncom

# Optional Edge TTS
try:
    import edge_tts
    import pygame
    pygame.mixer.init()
    EDGE_AVAILABLE = True
except Exception:
    EDGE_AVAILABLE = False


class TTSEngine:
    def __init__(self, engine_type="sapi5", voice="", rate=0, volume=100, on_speech_start=None, on_speech_end=None):
        self.engine_type = engine_type  # "sapi5" or "edge_tts"
        self.voice = voice
        self.rate = rate                # -10 to 10 for sapi5
        self.volume = volume            # 0 to 100
        self.on_speech_start = on_speech_start
        self.on_speech_end = on_speech_end
        
        self.is_speaking = False
        self._stop_requested = False
        self._lock = threading.Lock()
        self._current_thread = None

    def get_sapi5_voices(self):
        voices = []
        try:
            pythoncom.CoInitialize()
            sp = win32com.client.Dispatch("SAPI.SpVoice")
            v_list = sp.GetVoices()
            for i in range(v_list.Count):
                v = v_list.Item(i)
                desc = v.GetDescription()
                voices.append({"name": desc, "id": desc, "type": "sapi5"})
        except Exception as e:
            print(f"[TTSEngine] Error getting SAPI5 voices: {e}")
        return voices

    def get_popular_edge_voices(self):
        if not EDGE_AVAILABLE:
            return []
        return [
            {"name": "Microsoft Jenny (US Neural - Natural)", "id": "en-US-JennyNeural", "type": "edge_tts"},
            {"name": "Microsoft Guy (US Neural - Natural)", "id": "en-US-GuyNeural", "type": "edge_tts"},
            {"name": "Microsoft Sonia (UK Neural - Natural)", "id": "en-GB-SoniaNeural", "type": "edge_tts"},
            {"name": "Microsoft Ryan (UK Neural - Natural)", "id": "en-GB-RyanNeural", "type": "edge_tts"},
            {"name": "Microsoft Swara (India Neural)", "id": "hi-IN-SwaraNeural", "type": "edge_tts"},
            {"name": "Microsoft Madhur (India Neural)", "id": "hi-IN-MadhurNeural", "type": "edge_tts"},
        ]

    def get_all_voices(self):
        v = self.get_sapi5_voices()
        v.extend(self.get_popular_edge_voices())
        return v

    def stop(self):
        self._stop_requested = True
        try:
            pythoncom.CoInitialize()
            sp = win32com.client.Dispatch("SAPI.SpVoice")
            # Flag 2 = SVSFPurgeBeforeSpeak (clears queue)
            sp.Speak("", 2)
        except Exception:
            pass

        if EDGE_AVAILABLE:
            try:
                if pygame.mixer.get_init() and pygame.mixer.music.get_busy():
                    pygame.mixer.music.stop()
            except Exception:
                pass

        self.is_speaking = False
        if self.on_speech_end:
            try:
                self.on_speech_end()
            except Exception:
                pass

    def _speak_sapi5(self, text: str):
        try:
            pythoncom.CoInitialize()
            sp = win32com.client.Dispatch("SAPI.SpVoice")
            
            # Set rate and volume
            sp.Rate = int(max(-10, min(10, self.rate)))
            sp.Volume = int(max(0, min(100, self.volume)))
            
            # Match voice if set
            if self.voice:
                voices = sp.GetVoices()
                for i in range(voices.Count):
                    v = voices.Item(i)
                    if self.voice in v.GetDescription():
                        sp.Voice = v
                        break
                        
            # SVSFlagsAsync = 1
            sp.Speak(text, 1)
            
            # Wait while speaking
            while sp.Status.RunningState == 2 and not self._stop_requested:
                time.sleep(0.05)
                
            if self._stop_requested:
                sp.Speak("", 2)
        except Exception as e:
            print(f"[TTSEngine] SAPI5 speak error: {e}")
        finally:
            self.is_speaking = False
            if self.on_speech_end:
                self.on_speech_end()

    def _speak_edge(self, text: str, voice_id: str):
        temp_file = None
        try:
            # Generate edge audio
            async def _generate():
                communicate = edge_tts.Communicate(text, voice_id)
                fd, path = tempfile.mkstemp(suffix=".mp3")
                os.close(fd)
                await communicate.save(path)
                return path

            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            temp_file = loop.run_until_complete(_generate())
            loop.close()

            if self._stop_requested:
                return

            # Play with pygame
            pygame.mixer.music.load(temp_file)
            pygame.mixer.music.set_volume(self.volume / 100.0)
            pygame.mixer.music.play()

            while pygame.mixer.music.get_busy() and not self._stop_requested:
                time.sleep(0.05)

            if self._stop_requested:
                pygame.mixer.music.stop()

        except Exception as e:
            print(f"[TTSEngine] Edge TTS error: {e}")
            # Fallback to SAPI5
            self._speak_sapi5(text)
            return
        finally:
            if temp_file and os.path.exists(temp_file):
                try:
                    pygame.mixer.music.unload()
                    os.remove(temp_file)
                except Exception:
                    pass
            self.is_speaking = False
            if self.on_speech_end:
                self.on_speech_end()

    def speak(self, text: str):
        if not text or not text.strip():
            return
            
        self.stop()
        self._stop_requested = False
        self.is_speaking = True
        
        if self.on_speech_start:
            self.on_speech_start()

        def _worker():
            if self.engine_type == "edge_tts" and EDGE_AVAILABLE and self.voice.endswith("Neural"):
                self._speak_edge(text, self.voice)
            else:
                self._speak_sapi5(text)

        self._current_thread = threading.Thread(target=_worker, daemon=True)
        self._current_thread.start()

    def save_audio(self, text: str, output_path: str):
        """Export text to audio file (.wav for SAPI5 or .mp3 for Edge)"""
        if not text:
            return False
            
        if self.engine_type == "edge_tts" and EDGE_AVAILABLE and self.voice.endswith("Neural"):
            try:
                async def _save():
                    comm = edge_tts.Communicate(text, self.voice)
                    await comm.save(output_path)
                asyncio.run(_save())
                return True
            except Exception as e:
                print(f"[TTSEngine] Edge save error: {e}")
                return False
        else:
            try:
                pythoncom.CoInitialize()
                sp = win32com.client.Dispatch("SAPI.SpVoice")
                fs = win32com.client.Dispatch("SAPI.SpFileStream")
                # 3 = SSFMCreateForWrite
                fs.Open(output_path, 3)
                sp.AudioOutputStream = fs
                sp.Speak(text)
                fs.Close()
                return True
            except Exception as e:
                print(f"[TTSEngine] SAPI save error: {e}")
                return False
