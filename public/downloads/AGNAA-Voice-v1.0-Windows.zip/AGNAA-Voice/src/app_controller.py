import os
import sys
import time
import threading
import tkinter as tk

from .config import ConfigManager
from .audio_recorder import AudioRecorder
from .stt_engine import STTEngine
from .tts_engine import TTSEngine
from .text_injector import TextInjector
from .hotkey_manager import HotkeyManager
from .sound_effects import SoundEffects
from .history_manager import HistoryManager
from .hud_overlay import HUDOverlay
from .tray_icon import TrayIcon
from .smart_formatter import SmartFormatter

class AppController:
    def __init__(self):
        self.config = ConfigManager()
        self.history = HistoryManager()
        self.sounds = SoundEffects(enabled=self.config.get("sound_feedback", True))
        
        # Audio & AI engines
        self.recorder = AudioRecorder(
            sample_rate=16000,
            device_index=self.config.get("input_device_index"),
            on_audio_level=self._on_audio_level,
            on_silence_timeout=self._on_silence_timeout
        )
        
        self.stt = STTEngine(
            model_size=self.config.get("whisper_model", "base"),
            device=self.config.get("device", "cpu"),
            compute_type=self.config.get("compute_type", "int8")
        )
        
        self.tts = TTSEngine(
            engine_type=self.config.get("tts_engine", "sapi5"),
            voice=self.config.get("tts_voice", ""),
            rate=self.config.get("tts_rate", 0),
            volume=self.config.get("tts_volume", 100),
            on_speech_start=self._on_speech_start,
            on_speech_end=self._on_speech_end
        )
        
        self.injector = TextInjector()
        
        # UI references (will be attached after Tk root init)
        self.root = None
        self.gui = None
        self.hud = None
        self.tray = None
        
        self.target_hwnd = None
        self._is_transcribing = False

    def init_ui_and_services(self, root, gui):
        self.root = root
        self.gui = gui

        # HUD Overlay
        self.hud = HUDOverlay(self.root, self.config)

        # Tray Icon
        self.tray = TrayIcon(
            on_open_gui=self.show_gui,
            on_toggle_stt=self.toggle_dictation,
            on_read_tts=self.read_selected_text,
            on_stop=self.stop_all,
            on_exit=self.shutdown
        )
        self.tray.start()

        # Hotkeys
        self.hotkeys = HotkeyManager(
            self.config,
            on_stt_toggle=self.toggle_dictation,
            on_stt_press=self.start_dictation,
            on_stt_release=self.stop_dictation,
            on_tts_read=self.read_selected_text,
            on_stop_action=self.stop_all
        )
        self.hotkeys.register_all()

        # Load Whisper model asynchronously in background so app starts instantly
        threading.Thread(target=self._initial_model_load, daemon=True).start()

    def _initial_model_load(self):
        self.stt.load()
        if self.gui:
            self.root.after(0, lambda: self.gui.status_badge.configure(
                text=f"Ready • Hotkey: {self.config.get('stt_hotkey', 'f8').upper()} • Model: {self.config.get('whisper_model', 'base').upper()}"
            ))

    def _on_audio_level(self, rms: float):
        if self.hud:
            self.hud.update_audio_level(rms)

    def _on_silence_timeout(self):
        if self.recorder.is_recording and self.config.get("vad_silence_stop", False):
            self.stop_dictation()

    def show_gui(self):
        if self.gui:
            self.root.after(0, lambda: (self.gui.deiconify(), self.gui.lift(), self.gui.focus_force()))

    # =========================================================================
    # DICTATION / SPEECH-TO-TEXT LOGIC
    # =========================================================================
    def toggle_dictation(self):
        if self.recorder.is_recording:
            self.stop_dictation()
        else:
            self.start_dictation()

    def start_dictation(self):
        if self._is_transcribing or self.recorder.is_recording:
            return

        # Record foreground window so we can paste back to it reliably
        self.target_hwnd = self.injector.get_foreground_window()

        # Stop any active TTS reading
        if self.tts.is_speaking:
            self.tts.stop()

        ok = self.recorder.start()
        if ok:
            self.sounds.play_record_start()
            if self.hud:
                self.root.after(0, self.hud.set_recording)
            if self.gui:
                self.root.after(0, lambda: self.gui.update_dictation_ui_state("recording"))
            if self.tray:
                self.tray.set_state("recording")

    def stop_dictation(self):
        if not self.recorder.is_recording:
            return

        self.sounds.play_record_stop()
        audio = self.recorder.stop()
        duration = len(audio) / 16000.0

        if len(audio) < 2400: # Less than 0.15s
            if self.hud:
                self.root.after(0, self.hud._restore_idle)
            if self.gui:
                self.root.after(0, lambda: self.gui.update_dictation_ui_state("idle"))
            if self.tray:
                self.tray.set_state("idle")
            return

        self._is_transcribing = True
        if self.hud:
            self.root.after(0, self.hud.set_transcribing)
        if self.gui:
            self.root.after(0, lambda: self.gui.update_dictation_ui_state("transcribing"))
        if self.tray:
            self.tray.set_state("transcribing")

        # Run transcription in worker thread
        threading.Thread(target=self._transcribe_worker, args=(audio, duration), daemon=True).start()

    def _transcribe_worker(self, audio, duration):
        try:
            lang = self.config.get("language", "auto")
            task = self.config.get("task", "transcribe")
            text, detected_lang, proc_time = self.stt.transcribe(audio, language=lang, task=task)

            if text:
                # Apply smart formatting (CAD / Clean / Natural)
                mode = self.config.get("typing_mode", "general")
                text = SmartFormatter.format_text(text, mode=mode)

                print(f"[AppController] Transcribed ({proc_time:.2f}s) [{mode}]: {text}")
                # Save to history
                meta = f"{detected_lang.upper()} • {self.config.get('whisper_model').upper()}"
                self.history.add_entry("stt", text, duration=duration, meta=meta)

                # Paste text to active window
                self.injector.inject_text(
                    text=text,
                    method=self.config.get("paste_method", "clipboard"),
                    trailing_space=self.config.get("trailing_space", True),
                    target_hwnd=self.target_hwnd
                )

                if self.hud:
                    self.root.after(0, lambda: self.hud.set_success(text))
                if self.gui:
                    self.root.after(0, lambda: (
                        self.gui.update_dictation_ui_state("idle", text, duration=duration),
                        self.gui.refresh_history()
                    ))
            else:
                if self.hud:
                    self.root.after(0, self.hud._restore_idle)
                if self.gui:
                    self.root.after(0, lambda: self.gui.update_dictation_ui_state("idle"))

        except Exception as e:
            print(f"[AppController] Transcription worker error: {e}")
            if self.hud:
                self.root.after(0, self.hud._restore_idle)
            if self.gui:
                self.root.after(0, lambda: self.gui.update_dictation_ui_state("idle"))
        finally:
            self._is_transcribing = False
            if self.tray:
                self.tray.set_state("idle")

    # =========================================================================
    # TEXT-TO-SPEECH LOGIC
    # =========================================================================
    def read_selected_text(self):
        if self.tts.is_speaking:
            self.tts.stop()
            return

        text = self.injector.get_selected_text()
        if not text:
            if self.hud:
                self.root.after(0, lambda: self.hud.set_success("Highlight text first"))
            return

        self.sounds.play_tts_start()
        self.history.add_entry("tts", text, meta=self.config.get("tts_voice", "Default"))
        if self.gui:
            self.root.after(0, lambda: self.gui.refresh_history())

        self.tts.speak(text)

    def _on_speech_start(self):
        if self.hud:
            self.root.after(0, self.hud.set_speaking)
        if self.tray:
            self.tray.set_state("speaking")

    def _on_speech_end(self):
        if self.hud:
            self.root.after(0, self.hud.set_stopped_speech)
        if self.tray:
            self.tray.set_state("idle")

    # =========================================================================
    # GENERAL ACTIONS
    # =========================================================================
    def stop_all(self):
        """Esc key action: stop speech or cancel recording"""
        if self.tts.is_speaking:
            self.tts.stop()
        if self.recorder.is_recording:
            self.recorder.stop()
            if self.hud:
                self.root.after(0, self.hud._restore_idle)
            if self.gui:
                self.root.after(0, lambda: self.gui.update_dictation_ui_state("idle"))
            if self.tray:
                self.tray.set_state("idle")

    def apply_settings_update(self):
        self.sounds.set_enabled(self.config.get("sound_feedback", True))
        self.recorder.set_device(self.config.get("input_device_index"))
        self.hotkeys.register_all()
        
        # Check if Whisper model changed
        current_m = self.config.get("whisper_model")
        current_d = self.config.get("device")
        if self.stt.model_size != current_m or self.stt.device != current_d:
            threading.Thread(target=lambda: self.stt.load(current_m, current_d), daemon=True).start()

        if self.hud:
            if self.config.get("show_hud", True):
                self.hud.show()
            else:
                self.hud.hide()

    def shutdown(self):
        print("[AppController] Shutting down BuzzVoice...")
        self.hotkeys.unregister_all()
        self.recorder.stop()
        self.tts.stop()
        if self.tray:
            self.tray.stop()
        if self.root:
            self.root.after(50, self.root.destroy)
        sys.exit(0)
