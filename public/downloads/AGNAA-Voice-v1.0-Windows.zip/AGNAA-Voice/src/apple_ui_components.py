import time
import math
import tkinter as tk
from PIL import Image, ImageDraw, ImageTk

class AppleOrb(tk.Canvas):
    """
    Apple / Siri style interactive Voice Orb with concentric glowing aura rings,
    real-time acoustic amplitude pulsing, specular glass sheen, and minimalist vector iconography.
    """
    def __init__(self, parent, size=140, on_click=None, bg_color="#14141F"):
        super().__init__(parent, width=size, height=size, bg=bg_color, highlightthickness=0)
        self.size = size
        self.on_click = on_click
        self.bg_color = bg_color
        
        self.state = "idle"  # "idle", "recording", "transcribing", "success"
        self.pulse_phase = 0.0
        self.audio_level = 0.0  # Normalized 0.0 to 1.0
        self.target_level = 0.0
        self.is_hovered = False
        
        self.bind("<Button-1>", self._handle_click)
        self.bind("<Enter>", self._handle_enter)
        self.bind("<Leave>", self._handle_leave)
        
        self._animate_loop()

    def set_state(self, state: str):
        self.state = state
        self._redraw()

    def set_audio_level(self, rms: float):
        # Normalize and smooth rms for realistic organic expansion
        norm = min(1.0, max(0.0, rms * 18.0))
        self.target_level = norm

    def _handle_click(self, event):
        if self.on_click:
            self.on_click()

    def _handle_enter(self, event):
        self.is_hovered = True
        self.config(cursor="hand2")
        self._redraw()

    def _handle_leave(self, event):
        self.is_hovered = False
        self.config(cursor="")
        self._redraw()

    def _animate_loop(self):
        self.pulse_phase += 0.09
        # Smoothly interpolate audio level toward target
        self.audio_level += (self.target_level - self.audio_level) * 0.35
        self.target_level *= 0.88  # gradual decay

        if self.state in ("recording", "transcribing"):
            self._redraw()
        elif self.is_hovered:
            self._redraw()
        
        self.after(35, self._animate_loop)

    def _redraw(self):
        self.delete("all")
        cx = self.size / 2
        cy = self.size / 2
        
        # -------------------------------------------------------------
        # STATE 1: RECORDING (Active Siri / Apple Listening State)
        # -------------------------------------------------------------
        if self.state == "recording":
            voice_boost = self.audio_level * 18
            ambient_pulse = math.sin(self.pulse_phase * 2.2) * 3.5
            core_r = 44 + (voice_boost * 0.4)
            
            # Outer aura 2 (diffused wave)
            aura2_r = 64 + voice_boost + ambient_pulse
            self.create_oval(cx - aura2_r, cy - aura2_r, cx + aura2_r, cy + aura2_r,
                              fill="", outline="#380A0A", width=1.5)
            
            # Outer aura 1 (glowing crimson ring)
            aura1_r = 54 + (voice_boost * 0.7) + ambient_pulse
            self.create_oval(cx - aura1_r, cy - aura1_r, cx + aura1_r, cy + aura1_r,
                              fill="", outline="#7F1D1D", width=2.5)
            
            # Mid energetic ring
            mid_r = 48 + (voice_boost * 0.5)
            self.create_oval(cx - mid_r, cy - mid_r, cx + mid_r, cy + mid_r,
                              fill="", outline="#DC2626", width=2)
            
            core_color_fill = "#EF4444"
            core_border = "#B91C1C"
            icon_color = "#FFFFFF"

        # -------------------------------------------------------------
        # STATE 2: TRANSCRIBING (Neural Processing Orbit)
        # -------------------------------------------------------------
        elif self.state == "transcribing":
            core_r = 43
            orbit_r = 52
            
            # Subtle amber ambient ring
            self.create_oval(cx - orbit_r, cy - orbit_r, cx + orbit_r, cy + orbit_r,
                              fill="", outline="#451A03", width=1.5)
            
            # Spinning Apple-style orbital arc
            spin_start = (self.pulse_phase * 140) % 360
            self.create_arc(cx - orbit_r, cy - orbit_r, cx + orbit_r, cy + orbit_r,
                            start=spin_start, extent=80, style="arc",
                            outline="#F59E0B", width=3)
            
            core_color_fill = "#D97706"
            core_border = "#92400E"
            icon_color = "#FEF3C7"

        # -------------------------------------------------------------
        # STATE 3: SUCCESS (Quick Emerald Confirmation)
        # -------------------------------------------------------------
        elif self.state == "success":
            core_r = 43
            success_r = 52
            self.create_oval(cx - success_r, cy - success_r, cx + success_r, cy + success_r,
                              fill="", outline="#059669", width=2)
            core_color_fill = "#10B981"
            core_border = "#047857"
            icon_color = "#FFFFFF"

        # -------------------------------------------------------------
        # STATE 4: IDLE (Luxury AGNAA Violet & Obsidian Glass)
        # -------------------------------------------------------------
        else:
            hover_delta = 3 if self.is_hovered else 0
            core_r = 42 + hover_delta
            
            # Ambient outer aura ring
            outer_ring_r = 56 + hover_delta
            ring_color = "#3A2368" if self.is_hovered else "#1F1B38"
            self.create_oval(cx - outer_ring_r, cy - outer_ring_r, cx + outer_ring_r, cy + outer_ring_r,
                              fill="", outline=ring_color, width=1.5)
            
            # Concentric mid ring
            mid_ring_r = 49 + hover_delta
            mid_ring_color = "#58288D" if self.is_hovered else "#2A224E"
            self.create_oval(cx - mid_ring_r, cy - mid_ring_r, cx + mid_ring_r, cy + mid_ring_r,
                              fill="", outline=mid_ring_color, width=2)
            
            core_color_fill = "#7B2DBF" if self.is_hovered else "#6D28D9"
            core_border = "#1C1C72"
            icon_color = "#FFFFFF"

        # -------------------------------------------------------------
        # 2. CORE SPHERE WITH DOUBLE CONCENTRIC HIGHLIGHT
        # -------------------------------------------------------------
        # Main Sphere
        self.create_oval(cx - core_r, cy - core_r, cx + core_r, cy + core_r,
                          fill=core_color_fill, outline=core_border, width=2.5)

        # Top Specular Glass Sheen (Apple Bubble Gloss)
        gloss_w = core_r * 0.72
        gloss_h = core_r * 0.38
        self.create_oval(cx - gloss_w, cy - core_r + 4, cx + gloss_w, cy - core_r + 4 + gloss_h,
                          fill="", outline="#FFFFFF", width=1.2)

        # -------------------------------------------------------------
        # 3. MINIMALIST APPLE-STYLE VECTOR MICROPHONE ICON
        # -------------------------------------------------------------
        # Main capsule mic body
        mw = 7
        mh = 16
        self.create_line(cx, cy - mh/2 + 1, cx, cy + mh/2 - 4, fill=icon_color, width=mw, capstyle="round")
        
        # Cradle arc wrapping under capsule
        cradle_r = 10
        self.create_arc(cx - cradle_r, cy - 3, cx + cradle_r, cy + cradle_r + 5,
                        start=0, extent=180, style="arc", outline=icon_color, width=2.2)
        
        # Stem
        self.create_line(cx, cy + cradle_r + 5, cx, cy + cradle_r + 12, fill=icon_color, width=2.2)
        
        # Pedestal foot
        self.create_line(cx - 6, cy + cradle_r + 12, cx + 6, cy + cradle_r + 12,
                         fill=icon_color, width=2.5, capstyle="round")
