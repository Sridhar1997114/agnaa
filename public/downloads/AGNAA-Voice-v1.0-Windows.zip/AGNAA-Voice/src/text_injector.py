import time
import ctypes
import pyperclip
import keyboard

user32 = ctypes.windll.user32
VK_CONTROL = 0x11
VK_C = 0x43
VK_V = 0x56
KEYEVENTF_KEYUP = 0x0002

class TextInjector:
    def __init__(self):
        pass

    @staticmethod
    def get_foreground_window():
        return user32.GetForegroundWindow()

    @staticmethod
    def set_foreground_window(hwnd):
        if hwnd:
            try:
                user32.SetForegroundWindow(hwnd)
            except Exception:
                pass

    @staticmethod
    def inject_text(text: str, method: str = "clipboard", trailing_space: bool = True, restore_clipboard: bool = True, target_hwnd=None):
        if not text:
            return

        if trailing_space and not text.endswith((" ", "\n", "\t")):
            text = text + " "

        if target_hwnd:
            TextInjector.set_foreground_window(target_hwnd)
            time.sleep(0.04)

        if method == "type":
            try:
                keyboard.write(text, delay=0.005)
                return
            except Exception as e:
                print(f"[TextInjector] Direct typing failed, falling back to clipboard: {e}")

        # Clipboard paste method (Fast, supports full unicode, instant)
        old_clip = ""
        has_old_clip = False
        try:
            old_clip = pyperclip.paste()
            has_old_clip = True
        except Exception:
            pass

        try:
            pyperclip.copy(text)
            time.sleep(0.04)

            # Send Ctrl+V
            user32.keybd_event(VK_CONTROL, 0, 0, 0)
            user32.keybd_event(VK_V, 0, 0, 0)
            time.sleep(0.05)
            user32.keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
            user32.keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)

            # Allow target window time to consume clipboard data
            time.sleep(0.12)
        finally:
            if restore_clipboard and has_old_clip:
                try:
                    pyperclip.copy(old_clip)
                except Exception:
                    pass

    @staticmethod
    def get_selected_text() -> str:
        """Copies highlighted text from currently active window via Ctrl+C"""
        old_clip = ""
        has_old_clip = False
        try:
            old_clip = pyperclip.paste()
            has_old_clip = True
        except Exception:
            pass

        marker = "__BUZZ_SEL_MARKER_99__"
        try:
            pyperclip.copy(marker)
            time.sleep(0.04)

            # Send Ctrl+C
            user32.keybd_event(VK_CONTROL, 0, 0, 0)
            user32.keybd_event(VK_C, 0, 0, 0)
            time.sleep(0.05)
            user32.keybd_event(VK_C, 0, KEYEVENTF_KEYUP, 0)
            user32.keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)

            time.sleep(0.08)
            new_clip = pyperclip.paste()
            if new_clip and new_clip != marker:
                return new_clip.strip()
            return ""
        finally:
            if has_old_clip and old_clip != marker:
                try:
                    pyperclip.copy(old_clip)
                except Exception:
                    pass
