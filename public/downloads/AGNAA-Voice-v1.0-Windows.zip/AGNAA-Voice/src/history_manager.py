import os
import json
import time
import csv
from pathlib import Path
from datetime import datetime

class HistoryManager:
    def __init__(self, history_file: str = None):
        if history_file is None:
            base_dir = Path(__file__).resolve().parent.parent
            self.history_file = base_dir / "history.json"
        else:
            self.history_file = Path(history_file)
            
        self.entries = []
        self.load()

    def load(self):
        if self.history_file.exists():
            try:
                with open(self.history_file, "r", encoding="utf-8") as f:
                    self.entries = json.load(f)
            except Exception as e:
                print(f"[HistoryManager] Error loading history: {e}")
                self.entries = []
        else:
            self.entries = []

    def save(self):
        try:
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump(self.entries, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[HistoryManager] Error saving history: {e}")

    def add_entry(self, entry_type: str, text: str, duration: float = 0.0, meta: str = ""):
        if not text or not text.strip():
            return
            
        item = {
            "id": int(time.time() * 1000),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "type": entry_type,    # "stt" or "tts"
            "text": text.strip(),
            "duration": round(duration, 2),
            "meta": meta
        }
        self.entries.insert(0, item)  # Newest first
        if len(self.entries) > 500:   # Keep last 500
            self.entries = self.entries[:500]
        self.save()
        return item

    def get_entries(self, filter_type=None, search_query=None):
        results = self.entries
        if filter_type:
            results = [e for e in results if e.get("type") == filter_type]
        if search_query:
            q = search_query.lower()
            results = [e for e in results if q in e.get("text", "").lower()]
        return results

    def clear(self):
        self.entries = []
        self.save()

    def export_txt(self, export_path: str):
        try:
            with open(export_path, "w", encoding="utf-8") as f:
                for e in self.entries:
                    f.write(f"[{e['timestamp']}] ({e['type'].upper()} - {e.get('duration', 0)}s)\n")
                    f.write(f"{e['text']}\n\n")
            return True
        except Exception as e:
            print(f"[HistoryManager] Export TXT failed: {e}")
            return False

    def export_csv(self, export_path: str):
        try:
            with open(export_path, "w", encoding="utf-8", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["Timestamp", "Type", "Text", "Duration (s)", "Details"])
                for e in self.entries:
                    writer.writerow([
                        e.get("timestamp", ""),
                        e.get("type", ""),
                        e.get("text", ""),
                        e.get("duration", 0),
                        e.get("meta", "")
                    ])
            return True
        except Exception as e:
            print(f"[HistoryManager] Export CSV failed: {e}")
            return False
