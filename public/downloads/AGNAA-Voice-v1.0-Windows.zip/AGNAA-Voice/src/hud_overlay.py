import time
import tkinter as tk
from PIL import Image, ImageTk
import os
import win32gui
import win32con

class HUDOverlay:
    """
    Ultra-sleek Floating Dynamic Capsule HUD for AGNAA Voice.
    Features:
    - Glassmorphism dark aesthetic (#0C0C14 with purple/indigo hairline border)
    - Live animated soundwave visualizer
    - Non-activating window (WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW) that NEVER steals focus
    - Draggable anywhere, remembers screen position
    - Live recording timer & snippet preview
    """
    def __init__(self, root, config_manager, on_click_action=None):
        self.root = root
        self.config = config_manager
        self.on_click_action = on_click_action

        self.window = tk.Toplevel(root)
        self.window.title("AGNAA Voice HUD")
        self.window.overrideredirect(True)
        self.window.attributes("-topmost", True)
        self.window.attributes("-alpha", 0.95)

        # Style tokens (Official AGNAA Design Studio Theme)
        self.bg_color = "#0D0D14"       # AGNAA Dark
        self.border_color = "#2E2A4A"   # AGNAA Border Violet Tint
        self.text_color = "#F0F0F6"     # AGNAA Light
        self.muted_color = "#8888AA"    # AGNAA Muted
        self.accent_color = "#7B2DBF"   # AGNAA Violet
        self.navy_color = "#1C1C72"     # AGNAA Navy
        self.glow_color = "#C084FC"     # AGNAA Lilac Highlight

        self.window.configure(bg=self.border_color)

        # Dragging state
        self._drag_start_x = 0
        self._drag_start_y = 0

        # Inner container
        self.inner_frame = tk.Frame(self.window, bg=self.bg_color, padx=14, pady=6)
        self.inner_frame.pack(padx=1, pady=1, fill="both", expand=True)

        # Logo badge
        self.logo_img = None
        logo_path = os.path.join(os.path.dirname(__file__), "..", "assets", "icon.png")
        if os.path.exists(logo_path):
            try:
                pil_im = Image.open(logo_path).resize((22, 22), Image.Resampling.LANCZOS)
                self.logo_img = ImageTk.PhotoImage(pil_im)
                self.logo_lbl = tk.Label(self.inner_frame, image=self.logo_img, bg=self.bg_color)
                self.logo_lbl.pack(side="left", padx=(0, 8))
            except Exception:
                self.logo_lbl = tk.Label(self.inner_frame, text="⚡", font=("Segoe UI", 11), bg=self.bg_color, fg="#818CF8")
                self.logo_lbl.pack(side="left", padx=(0, 8))
        else:
            self.logo_lbl = tk.Label(self.inner_frame, text="⚡", font=("Segoe UI", 11), bg=self.bg_color, fg="#818CF8")
            self.logo_lbl.pack(side="left", padx=(0, 8))

        # Status text
        self.status_label = tk.Label(
            self.inner_frame,
            text="AGNAA Voice",
            font=("Segoe UI", 9, "bold"),
            bg=self.bg_color,
            fg=self.text_color
        )
        self.status_label.pack(side="left", padx=(0, 8))

        # Wave canvas for smooth animated audio bars
        self.wave_canvas = tk.Canvas(self.inner_frame, width=48, height=18, bg=self.bg_color, highlightthickness=0)
        self.wave_canvas.pack(side="left", padx=(0, 6))

        # Timer label
        self.timer_label = tk.Label(
            self.inner_frame,
            text="",
            font=("Consolas", 9, "bold"),
            bg=self.bg_color,
            fg=self.muted_color
        )
        self.timer_label.pack(side="left")

        # Bind dragging across all widgets
        for widget in (self.window, self.inner_frame, self.logo_lbl, self.status_label, self.wave_canvas, self.timer_label):
            widget.bind("<ButtonPress-1>", self._start_drag)
            widget.bind("<B1-Motion>", self._on_drag)
            widget.bind("<ButtonRelease-1>", self._end_drag)

        # Apply Windows WS_EX_NOACTIVATE style so clicking HUD never steals focus
        self._apply_no_activate()

        # Set default position
        self._init_position()

        self.auto_hide_timer = None
        self.record_start_time = 0
        self.is_recording = False
        self.state = "idle"

        if not self.config.get("show_hud", True):
            self.window.withdraw()
        else:
            self._restore_idle()

    def _apply_no_activate(self):
        try:
            self.window.update_idletasks()
            hwnd = win32gui.GetParent(self.window.winfo_id())
            if not hwnd:
                hwnd = self.window.winfo_id()
            ex_style = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
            win32gui.SetWindowLong(
                hwnd,
                win32con.GWL_EXSTYLE,
                ex_style | win32con.WS_EX_NOACTIVATE | win32con.WS_EX_TOOLWINDOW
            )
        except Exception as e:
            print(f"[HUDOverlay] Failed to apply WS_EX_NOACTIVATE: {e}")

    def _init_position(self):
        self.window.update_idletasks()
        w = 280
        h = 38
        saved_x = self.config.get("hud_x")
        saved_y = self.config.get("hud_y")

        screen_w = self.window.winfo_screenwidth()
        screen_h = self.window.winfo_screenheight()

        if saved_x is not None and saved_y is not None:
            x, y = saved_x, saved_y
        else:
            x = screen_w - w - 40
            y = screen_h - h - 80

        self.window.geometry(f"{w}x{h}+{x}+{y}")

    def _start_drag(self, event):
        self._drag_start_x = event.x_root - self.window.winfo_x()
        self._drag_start_y = event.y_root - self.window.winfo_y()

    def _on_drag(self, event):
        new_x = event.x_root - self._drag_start_x
        new_y = event.y_root - self._drag_start_y
        self.window.geometry(f"+{new_x}+{new_y}")

    def _end_drag(self, event):
        self.config.set("hud_x", self.window.winfo_x())
        self.config.set("hud_y", self.window.winfo_y())

    def show(self):
        if self.config.get("show_hud", True):
            self.window.deiconify()
            self.window.lift()

    def hide(self):
        self.window.withdraw()

    def set_recording(self):
        self.state = "recording"
        self.is_recording = True
        self.record_start_time = time.time()
        if self.auto_hide_timer:
            self.root.after_cancel(self.auto_hide_timer)
            self.auto_hide_timer = None

        self.window.configure(bg="#DC2626") # Red border
        self.status_label.configure(text="Listening...", fg="#F87171")
        self._update_timer_loop()
        self.show()

    def _update_timer_loop(self):
        if not self.is_recording:
            return
        elapsed = int(time.time() - self.record_start_time)
        mins = elapsed // 60
        secs = elapsed % 60
        self.timer_label.configure(text=f"{mins:02d}:{secs:02d}")
        self.root.after(500, self._update_timer_loop)

    def update_audio_level(self, rms: float):
        if self.state != "recording":
            return
        try:
            self.wave_canvas.delete("all")
            # Draw 5 animated smooth bars
            num_bars = 5
            bar_w = 5
            gap = 4
            max_h = 16
            norm = min(1.0, rms * 20.0)

            for i in range(num_bars):
                # Pseudo-dynamic heights based on index and norm
                factor = [0.4, 0.8, 1.0, 0.7, 0.5][i]
                h = max(2, int(max_h * norm * factor))
                x0 = i * (bar_w + gap) + 4
                y0 = (max_h - h) // 2 + 1
                x1 = x0 + bar_w
                y1 = y0 + h
                color = "#EF4444" if i % 2 == 0 else "#F87171"
                self.wave_canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline="")
        except Exception:
            pass

    def set_transcribing(self):
        self.state = "transcribing"
        self.is_recording = False
        self.window.configure(bg="#D97706") # Amber border
        self.status_label.configure(text="Transcribing...", fg="#FCD34D")
        self.wave_canvas.delete("all")
        self.timer_label.configure(text="")
        self.show()

    def set_success(self, snippet=""):
        self.state = "success"
        self.is_recording = False
        self.window.configure(bg="#059669") # Emerald border
        display = f"\"{snippet[:16]}...\"" if snippet else "Pasted!"
        self.status_label.configure(text=display, fg="#6EE7B7")
        self.wave_canvas.delete("all")
        self.timer_label.configure(text="")
        self.show()

        if self.auto_hide_timer:
            self.root.after_cancel(self.auto_hide_timer)
        self.auto_hide_timer = self.root.after(2200, self._restore_idle)

    def set_speaking(self, preview=""):
        self.state = "speaking"
        self.is_recording = False
        self.window.configure(bg="#2563EB") # Blue border
        self.status_label.configure(text="Speaking... (Esc)", fg="#93C5FD")
        self.wave_canvas.delete("all")
        self.timer_label.configure(text="")
        self.show()

    def set_stopped_speech(self):
        self._restore_idle()

    def _restore_idle(self):
        self.state = "idle"
        self.is_recording = False
        hk = self.config.get("stt_hotkey", "f8").upper()
        self.window.configure(bg=self.border_color)
        self.status_label.configure(text=f"AGNAA ({hk})", fg=self.text_color)
        self.wave_canvas.delete("all")
        self.timer_label.configure(text="")
