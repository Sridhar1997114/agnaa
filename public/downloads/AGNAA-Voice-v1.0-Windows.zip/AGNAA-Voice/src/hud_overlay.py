import time
import tkinter as tk
from PIL import Image, ImageTk
import os
import win32gui
import win32con

class HUDOverlay:
    """
    Apple Dynamic Island Floating HUD for AGNAA Voice.
    Design & Ergonomics:
    - Pure Jet-Black OLED capsule (#000000) with subtle hairline border (#26263A)
    - Dynamic status indicator glyph (Ruby Red listening, Amber transcribing, Emerald success, Blue reading)
    - Real-time acoustic soundwave visualizer
    - Non-activating window (WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW) - never steals focus
    - Smooth draggable positioning with configuration persistence
    - Live recording timer & hotkey indicator pill
    """
    def __init__(self, root, config_manager, on_click_action=None):
        self.root = root
        self.config = config_manager
        self.on_click_action = on_click_action

        self.window = tk.Toplevel(root)
        self.window.title("AGNAA Dynamic Island")
        self.window.overrideredirect(True)
        self.window.attributes("-topmost", True)
        self.window.attributes("-alpha", 0.96)

        # Brand Design Tokens
        self.bg_color = "#000000"       # Pure Apple OLED Black
        self.border_color = "#232336"   # Hairline subtle contour
        self.text_color = "#F4F4F8"     # Crisp Light
        self.muted_color = "#8E8EA0"    # Apple Muted Gray
        self.accent_color = "#7B2DBF"   # AGNAA Signature Violet
        self.navy_color = "#1C1C72"     # AGNAA Navy

        self.window.configure(bg=self.border_color)

        # Dragging state
        self._drag_start_x = 0
        self._drag_start_y = 0

        # Island Capsule Outer-to-Inner Container
        self.capsule = tk.Frame(self.window, bg=self.bg_color, padx=12, pady=5)
        self.capsule.pack(padx=1, pady=1, fill="both", expand=True)

        # 1. Left: Dynamic Status Dot Canvas (Pulsing Apple Indicator)
        self.indicator_canvas = tk.Canvas(self.capsule, width=20, height=20, bg=self.bg_color, highlightthickness=0)
        self.indicator_canvas.pack(side="left", padx=(2, 6))

        # 2. Status Label (Dynamic Island State)
        self.status_label = tk.Label(
            self.capsule,
            text="AGNAA Voice",
            font=("Segoe UI Variable Display", 9, "bold"),
            bg=self.bg_color,
            fg=self.text_color
        )
        self.status_label.pack(side="left", padx=(0, 6))

        # 3. Waveform Canvas (Live acoustic equalizer bars)
        self.wave_canvas = tk.Canvas(self.capsule, width=44, height=16, bg=self.bg_color, highlightthickness=0)
        self.wave_canvas.pack(side="left", padx=(0, 8))

        # 4. Right: Timer / Keycap Badge Pill
        self.badge_frame = tk.Frame(self.capsule, bg="#161622", padx=6, pady=2)
        self.badge_frame.pack(side="right", padx=(2, 2))

        self.badge_label = tk.Label(
            self.badge_frame,
            text=f"F8",
            font=("Segoe UI Variable Text", 8, "bold"),
            bg="#161622",
            fg=self.muted_color
        )
        self.badge_label.pack()

        # Bind dragging across all Dynamic Island elements
        for w in (self.window, self.capsule, self.indicator_canvas, self.status_label, self.wave_canvas, self.badge_frame, self.badge_label):
            w.bind("<ButtonPress-1>", self._start_drag)
            w.bind("<B1-Motion>", self._on_drag)
            w.bind("<ButtonRelease-1>", self._end_drag)

        # Apply Windows WS_EX_NOACTIVATE style so clicking HUD never steals focus
        self._apply_no_activate()

        # Set default position (top-right or saved coordinate)
        self._init_position()

        self.auto_hide_timer = None
        self.record_start_time = 0
        self.is_recording = False
        self.state = "idle"

        self._draw_indicator_dot("idle")

        if not self.config.get("show_hud", True):
            self.window.withdraw()
        else:
            self._restore_idle()

    def _apply_no_activate(self):
        try:
            self.window.update_idletasks()
            hwnd = win32gui.GetParent(self.window.winfo_id())
            if not hwnd:
                hwnd = self.window.winfo_id()
            ex_style = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
            win32gui.SetWindowLong(
                hwnd,
                win32con.GWL_EXSTYLE,
                ex_style | win32con.WS_EX_NOACTIVATE | win32con.WS_EX_TOOLWINDOW
            )
        except Exception as e:
            pass

    def _init_position(self):
        self.window.update_idletasks()
        w = 260
        h = 34
        saved_x = self.config.get("hud_x")
        saved_y = self.config.get("hud_y")

        screen_w = self.window.winfo_screenwidth()
        screen_h = self.window.winfo_screenheight()

        if saved_x is not None and saved_y is not None:
            x, y = saved_x, saved_y
        else:
            x = screen_w - w - 36
            y = 45 # Sleek top-right position

        self.window.geometry(f"{w}x{h}+{x}+{y}")

    def _start_drag(self, event):
        self._drag_start_x = event.x_root - self.window.winfo_x()
        self._drag_start_y = event.y_root - self.window.winfo_y()

    def _on_drag(self, event):
        new_x = event.x_root - self._drag_start_x
        new_y = event.y_root - self._drag_start_y
        self.window.geometry(f"+{new_x}+{new_y}")

    def _end_drag(self, event):
        self.config.set("hud_x", self.window.winfo_x())
        self.config.set("hud_y", self.window.winfo_y())

    def show(self):
        if self.config.get("show_hud", True):
            self.window.deiconify()
            self.window.lift()

    def hide(self):
        self.window.withdraw()

    def _draw_indicator_dot(self, state: str):
        self.indicator_canvas.delete("all")
        cx, cy = 10, 10
        if state == "recording":
            # Outer subtle glow
            self.indicator_canvas.create_oval(cx-8, cy-8, cx+8, cy+8, fill="", outline="#7F1D1D", width=1.5)
            # Inner vivid red dot
            self.indicator_canvas.create_oval(cx-5, cy-5, cx+5, cy+5, fill="#EF4444", outline="#B91C1C", width=1)
        elif state == "transcribing":
            self.indicator_canvas.create_oval(cx-7, cy-7, cx+7, cy+7, fill="", outline="#78350F", width=1.5)
            self.indicator_canvas.create_oval(cx-5, cy-5, cx+5, cy+5, fill="#F59E0B", outline="#B45309", width=1)
        elif state == "success":
            self.indicator_canvas.create_oval(cx-7, cy-7, cx+7, cy+7, fill="", outline="#064E3B", width=1.5)
            self.indicator_canvas.create_oval(cx-5, cy-5, cx+5, cy+5, fill="#10B981", outline="#047857", width=1)
        elif state == "speaking":
            self.indicator_canvas.create_oval(cx-7, cy-7, cx+7, cy+7, fill="", outline="#1E3A8A", width=1.5)
            self.indicator_canvas.create_oval(cx-5, cy-5, cx+5, cy+5, fill="#3B82F6", outline="#1D4ED8", width=1)
        else: # idle
            self.indicator_canvas.create_oval(cx-5, cy-5, cx+5, cy+5, fill="#7B2DBF", outline="#4A259C", width=1)

    def set_recording(self):
        self.state = "recording"
        self.is_recording = True
        self.record_start_time = time.time()
        if self.auto_hide_timer:
            self.root.after_cancel(self.auto_hide_timer)
            self.auto_hide_timer = None

        self.window.configure(bg="#DC2626") # Vibrant red border accent
        self.status_label.configure(text="Listening...", fg="#FCA5A5")
        self._draw_indicator_dot("recording")
        self._update_timer_loop()
        self.show()

    def _update_timer_loop(self):
        if not self.is_recording:
            return
        elapsed = int(time.time() - self.record_start_time)
        mins = elapsed // 60
        secs = elapsed % 60
        self.badge_label.configure(text=f"{mins:02d}:{secs:02d}", fg="#EF4444")
        self.root.after(500, self._update_timer_loop)

    def update_audio_level(self, rms: float):
        if self.state != "recording":
            return
        try:
            self.wave_canvas.delete("all")
            num_bars = 5
            bar_w = 4
            gap = 4
            max_h = 14
            norm = min(1.0, max(0.08, rms * 22.0))

            for i in range(num_bars):
                factor = [0.4, 0.85, 1.0, 0.75, 0.45][i]
                h = max(2, int(max_h * norm * factor))
                x0 = i * (bar_w + gap) + 4
                y0 = (max_h - h) // 2 + 1
                x1 = x0 + bar_w
                y1 = y0 + h
                color = "#EF4444" if i % 2 == 0 else "#F87171"
                self.wave_canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline="")
        except Exception:
            pass

    def set_transcribing(self):
        self.state = "transcribing"
        self.is_recording = False
        self.window.configure(bg="#D97706") # Amber border
        self.status_label.configure(text="Transcribing...", fg="#FDE68A")
        self._draw_indicator_dot("transcribing")
        self.wave_canvas.delete("all")
        self.badge_label.configure(text="AI", fg="#F59E0B")
        self.show()

    def set_success(self, snippet=""):
        self.state = "success"
        self.is_recording = False
        self.window.configure(bg="#059669") # Emerald border
        display = f"\"{snippet[:14]}...\"" if snippet else "Pasted!"
        self.status_label.configure(text=display, fg="#A7F3D0")
        self._draw_indicator_dot("success")
        self.wave_canvas.delete("all")
        self.badge_label.configure(text="OK", fg="#10B981")
        self.show()

        if self.auto_hide_timer:
            self.root.after_cancel(self.auto_hide_timer)
        self.auto_hide_timer = self.root.after(2200, self._restore_idle)

    def set_speaking(self, preview=""):
        self.state = "speaking"
        self.is_recording = False
        self.window.configure(bg="#2563EB") # Blue border
        self.status_label.configure(text="Reading Selected", fg="#BAE6FD")
        self._draw_indicator_dot("speaking")
        self.wave_canvas.delete("all")
        self.badge_label.configure(text="Esc", fg="#38BDF8")
        self.show()

    def set_stopped_speech(self):
        self._restore_idle()

    def _restore_idle(self):
        self.state = "idle"
        self.is_recording = False
        hk = self.config.get("stt_hotkey", "f8").upper()
        self.window.configure(bg=self.border_color)
        self.status_label.configure(text="AGNAA Voice", fg=self.text_color)
        self._draw_indicator_dot("idle")
        self.wave_canvas.delete("all")
        self.badge_label.configure(text=hk, fg=self.muted_color)
