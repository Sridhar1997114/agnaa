import time
import threading
import numpy as np
import sounddevice as sd

class AudioRecorder:
    def __init__(self, sample_rate=16000, device_index=None, on_audio_level=None, on_silence_timeout=None):
        self.sample_rate = sample_rate
        self.device_index = device_index
        self.on_audio_level = on_audio_level          # Callback func(rms: float)
        self.on_silence_timeout = on_silence_timeout  # Callback when user stopped speaking
        
        self.is_recording = False
        self._stream = None
        self._audio_chunks = []
        self._lock = threading.Lock()
        
        self.start_time = 0.0
        self.current_level = 0.0
        
        # Silence detection settings
        self.enable_silence_stop = False
        self.silence_threshold = 0.015
        self.silence_duration = 2.0
        self.last_voice_time = 0.0

    @staticmethod
    def list_input_devices():
        devices = []
        try:
            device_list = sd.query_devices()
            for i, dev in enumerate(device_list):
                if dev['max_input_channels'] > 0:
                    devices.append({
                        'index': i,
                        'name': dev['name'],
                        'hostapi': dev['hostapi'],
                        'channels': dev['max_input_channels']
                    })
        except Exception as e:
            print(f"[AudioRecorder] Error querying devices: {e}")
        return devices

    def set_device(self, device_index):
        self.device_index = device_index

    def _audio_callback(self, indata, frames, time_info, status):
        if status:
            pass
        if not self.is_recording:
            return
            
        data = indata.copy().flatten()
        with self._lock:
            self._audio_chunks.append(data)
            
        # Calculate RMS amplitude
        rms = float(np.sqrt(np.mean(data ** 2)))
        self.current_level = rms
        if self.on_audio_level:
            try:
                self.on_audio_level(rms)
            except Exception:
                pass
                
        # Silence detection
        now = time.time()
        if rms >= self.silence_threshold:
            self.last_voice_time = now
        elif self.enable_silence_stop and (now - self.start_time > 1.0):
            if (now - self.last_voice_time) >= self.silence_duration:
                if self.on_silence_timeout:
                    try:
                        self.on_silence_timeout()
                    except Exception:
                        pass

    def start(self):
        with self._lock:
            if self.is_recording:
                return False
            self._audio_chunks = []
            self.is_recording = True
            self.start_time = time.time()
            self.last_voice_time = time.time()

        try:
            self._stream = sd.InputStream(
                samplerate=self.sample_rate,
                channels=1,
                dtype="float32",
                device=self.device_index,
                callback=self._audio_callback,
                blocksize=1024
            )
            self._stream.start()
            return True
        except Exception as e:
            print(f"[AudioRecorder] Failed to start audio stream: {e}")
            self.is_recording = False
            return False

    def stop(self) -> np.ndarray:
        with self._lock:
            if not self.is_recording:
                return np.zeros(0, dtype=np.float32)
            self.is_recording = False

        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception as e:
                print(f"[AudioRecorder] Error closing stream: {e}")
            finally:
                self._stream = None

        with self._lock:
            if not self._audio_chunks:
                return np.zeros(0, dtype=np.float32)
            audio = np.concatenate(self._audio_chunks, axis=0)
            self._audio_chunks = []
            return audio

    def get_duration(self) -> float:
        if self.is_recording:
            return time.time() - self.start_time
        return 0.0
