import threading

class SoundEffects:
    """
    Non-intrusive sound effects manager.
    Motherboard/system speaker beeps (winsound.Beep) have been completely removed
    to ensure a clean, silent, and premium experience.
    """
    def __init__(self, enabled=True):
        self.enabled = enabled

    def set_enabled(self, enabled: bool):
        self.enabled = enabled

    def play_record_start(self):
        pass

    def play_record_stop(self):
        pass

    def play_tts_start(self):
        # Zero beeps when reading text - immediate clean speech
        pass
