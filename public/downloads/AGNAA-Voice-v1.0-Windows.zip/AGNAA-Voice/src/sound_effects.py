import threading
import winsound

class SoundEffects:
    def __init__(self, enabled=True):
        self.enabled = enabled

    def set_enabled(self, enabled: bool):
        self.enabled = enabled

    def _play_tone(self, freq: int, duration_ms: int):
        if not self.enabled:
            return
        try:
            winsound.Beep(freq, duration_ms)
        except Exception:
            pass

    def play_record_start(self):
        """High-pitched gentle chime on start recording"""
        if not self.enabled:
            return
        threading.Thread(target=self._play_tone, args=(880, 80), daemon=True).start()

    def play_record_stop(self):
        """Descending gentle chime on stop recording"""
        if not self.enabled:
            return
        threading.Thread(target=self._play_tone, args=(587, 80), daemon=True).start()

    def play_tts_start(self):
        """Subtle blip when TTS starts reading"""
        if not self.enabled:
            return
        threading.Thread(target=self._play_tone, args=(1046, 50), daemon=True).start()
