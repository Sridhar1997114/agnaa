import win32gui, win32process, sys

def inspect(target_pid):
    def callback(hwnd, extra):
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        if pid == target_pid:
            title = win32gui.GetWindowText(hwnd)
            visible = win32gui.IsWindowVisible(hwnd)
            print(f"HWND {hwnd} | Title: '{title}' | Visible: {visible}")
        return True
    win32gui.EnumWindows(callback, None)

if __name__ == "__main__":
    pid = int(sys.argv[1]) if len(sys.argv) > 1 else 29452
    inspect(pid)
