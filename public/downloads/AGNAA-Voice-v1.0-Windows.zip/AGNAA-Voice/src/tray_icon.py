import os
import threading
from PIL import Image, ImageDraw
import pystray

class TrayIcon:
    def __init__(self, on_open_gui, on_toggle_stt, on_read_tts, on_stop, on_exit):
        self.on_open_gui = on_open_gui
        self.on_toggle_stt = on_toggle_stt
        self.on_read_tts = on_read_tts
        self.on_stop = on_stop
        self.on_exit = on_exit

        self.icon = None
        self._thread = None
        self.current_state = "idle"

    def _create_image(self, state="idle"):
        assets_icon = os.path.join(os.path.dirname(__file__), "..", "assets", "icon.png")
        if os.path.exists(assets_icon):
            try:
                base = Image.open(assets_icon).convert("RGBA").resize((64, 64), Image.Resampling.LANCZOS)
                # Add status badge dot in bottom right
                draw = ImageDraw.Draw(base)
                color = "#10B981" # Green Idle
                if state == "recording":
                    color = "#EF4444" # Red
                elif state == "transcribing":
                    color = "#F59E0B" # Amber
                elif state == "speaking":
                    color = "#3B82F6" # Blue
                # Draw small status circle
                draw.ellipse((44, 44, 62, 62), fill=color, outline="#18181B", width=2)
                return base
            except Exception:
                pass

        # Fallback
        color = "#4F46E5"
        if state == "recording":
            color = "#EF4444"
        elif state == "transcribing":
            color = "#F59E0B"
        elif state == "speaking":
            color = "#3B82F6"

        img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.ellipse((4, 4, 60, 60), fill=color)
        return img

    def start(self):
        def _setup_icon():
            menu = pystray.Menu(
                pystray.MenuItem("🎙️ Toggle Dictation", lambda: self.on_toggle_stt()),
                pystray.MenuItem("🔊 Read Selected Text", lambda: self.on_read_tts()),
                pystray.MenuItem("🛑 Stop / Cancel", lambda: self.on_stop()),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("🖥️ Open AGNAA Voice", lambda: self.on_open_gui(), default=True),
                pystray.MenuItem("🌐 Visit agnaa.in", lambda: self._open_web()),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("❌ Exit", lambda: self.on_exit())
            )
            image = self._create_image("idle")
            self.icon = pystray.Icon("AGNAAVoice", image, "AGNAA Voice - agnaa.in", menu)
            self.icon.run()

    def _open_web(self):
        import webbrowser
        webbrowser.open("https://agnaa.in")

        self._thread = threading.Thread(target=_setup_icon, daemon=True)
        self._thread.start()

    def set_state(self, state):
        self.current_state = state
        if self.icon:
            try:
                self.icon.icon = self._create_image(state)
            except Exception:
                pass

    def stop(self):
        if self.icon:
            try:
                self.icon.stop()
            except Exception:
                pass
