Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")

strCurDir = FSO.GetParentFolderName(WScript.ScriptFullName)
strPythonW = strCurDir & "\.venv\Scripts\pythonw.exe"
strScript = strCurDir & "\run_buzzvoice.py"

If Not FSO.FileExists(strPythonW) Then
    MsgBox "Python environment not found at: " & strPythonW, vbCritical, "BuzzVoice Error"
    WScript.Quit
End If

WshShell.CurrentDirectory = strCurDir
' 0 = hide window, False = don't wait for completion
WshShell.Run """" & strPythonW & """ """ & strScript & """", 0, False
